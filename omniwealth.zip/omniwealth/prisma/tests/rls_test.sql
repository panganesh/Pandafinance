-- Tenant-isolation & audit-immutability checks. Run as a superuser on a scratch DB AFTER the RLS migration.
-- Expected: no_context_rows=0, A_sees=A savings, A_users_visible=1, cross-tenant INSERT rejected by RLS,
--           UPDATE/DELETE on AuditLog rejected, chain_breaks=0, Connection with plaintext token rejected.
\set ON_ERROR_STOP 0
DO $$ BEGIN CREATE ROLE app_login LOGIN IN ROLE omniwealth_app; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
INSERT INTO "User"(id,"oidcIssuer","oidcSubject",email) VALUES
 ('11111111-1111-1111-1111-111111111111','iss','a','a@x.io'),
 ('22222222-2222-2222-2222-222222222222','iss','b','b@x.io');
INSERT INTO "Account"(id,"userId",type,name,currency,"currentBalanceMinor","isLiability","balanceAsOf") VALUES
 (gen_random_uuid(),'11111111-1111-1111-1111-111111111111','SAVINGS','A savings','INR',100,false,now()),
 (gen_random_uuid(),'22222222-2222-2222-2222-222222222222','SAVINGS','B savings','INR',999,false,now());
SET ROLE app_login;
SELECT 'no_context_rows=' || count(*) FROM "Account";
BEGIN; SELECT set_config('app.current_user_id','11111111-1111-1111-1111-111111111111',true);
SELECT 'A_sees=' || string_agg(name, ',') FROM "Account";
SELECT 'A_users_visible=' || count(*) FROM "User";
UPDATE "Account" SET "currentBalanceMinor"=0 WHERE name='B savings';
SELECT 'B_untouched=' || (SELECT count(*) FROM "Account" WHERE name='B savings');
COMMIT;
BEGIN; SELECT set_config('app.current_user_id','11111111-1111-1111-1111-111111111111',true);
INSERT INTO "Account"(id,"userId",type,name,currency,"currentBalanceMinor","isLiability","balanceAsOf")
 VALUES (gen_random_uuid(),'22222222-2222-2222-2222-222222222222','CASH','planted','INR',1,false,now());
ROLLBACK;
BEGIN; SELECT set_config('app.current_user_id','11111111-1111-1111-1111-111111111111',true);
INSERT INTO "AuditLog"("userId","actorType",action) VALUES ('11111111-1111-1111-1111-111111111111','USER','AUTH_LOGIN');
INSERT INTO "AuditLog"("userId","actorType",action,metadata) VALUES ('11111111-1111-1111-1111-111111111111','SYSTEM','SYNC_SUCCEEDED','{"added":3}');
COMMIT;
BEGIN; SELECT set_config('app.current_user_id','22222222-2222-2222-2222-222222222222',true);
INSERT INTO "AuditLog"("userId","actorType",action) VALUES ('22222222-2222-2222-2222-222222222222','USER','AUTH_LOGIN');
SELECT 'B_audit_visible=' || count(*) FROM "AuditLog";
UPDATE "AuditLog" SET action='AUTH_LOGOUT';
COMMIT;
RESET ROLE;
DELETE FROM "AuditLog";
SELECT 'chain_breaks=' || count(*) FROM (SELECT "prevHash", lag(hash) OVER (ORDER BY id) AS expected FROM "AuditLog") s WHERE "prevHash" IS DISTINCT FROM expected;
SELECT 'audit_rows=' || count(*) FROM "AuditLog";
INSERT INTO "Connection"(id,"userId","institutionId",provider,"providerConnectionId","accessTokenCiphertext",scopes)
 VALUES (gen_random_uuid(),'11111111-1111-1111-1111-111111111111',gen_random_uuid(),'PLAID','item1','plaintext-token','{transactions}');
SELECT 'B_balance_still=' || "currentBalanceMinor" FROM "Account" WHERE name='B savings';  -- expect 999
