-- OmniWealth: Row-Level Security, least-privilege roles, immutable audit log.
-- Run after `prisma migrate` creates the tables.
--
-- Request flow: API connects as role `omniwealth_app` (NOT the table owner, NOT BYPASSRLS).
-- Every request runs inside a transaction that first executes:
--     SELECT set_config('app.current_user_id', '<uuid from verified JWT sub mapping>', true);
-- `true` = transaction-local, so pooled connections (PgBouncer txn mode) can't leak identity.

-- ── Roles ────────────────────────────────────────────────────────────────
DO $$ BEGIN
  CREATE ROLE omniwealth_app NOLOGIN NOBYPASSRLS;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE ROLE omniwealth_worker NOLOGIN NOBYPASSRLS;  -- sync workers also act per-user
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

GRANT USAGE ON SCHEMA public TO omniwealth_app, omniwealth_worker;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO omniwealth_app, omniwealth_worker;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO omniwealth_app, omniwealth_worker;

-- Helper: current tenant (NULL if unset → every policy evaluates false → zero rows).
CREATE OR REPLACE FUNCTION app_current_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(current_setting('app.current_user_id', true), '')::uuid
$$;

-- ── Tenant tables: identical owner-only policy ───────────────────────────
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'Connection','SyncJob','Account','Transaction','RecurringSeries',
    'Budget','BudgetLine','Goal','GoalContribution','InvestmentHolding',
    'TaxLot','NetWorthSnapshot','FinancialProfile'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I
         USING ("userId" = app_current_user_id())
         WITH CHECK ("userId" = app_current_user_id())', t);
  END LOOP;
END $$;

-- User: may only see/modify own row.
ALTER TABLE "User" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "User" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS self_only ON "User";
CREATE POLICY self_only ON "User"
  USING (id = app_current_user_id())
  WITH CHECK (id = app_current_user_id());

-- Category & CategoryRule: system rows (userId IS NULL) readable by all, writable by none via app role.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['Category','CategoryRule'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS read_system_or_own ON %I', t);
    EXECUTE format('DROP POLICY IF EXISTS write_own ON %I', t);
    EXECUTE format('CREATE POLICY read_system_or_own ON %I FOR SELECT
                      USING ("userId" IS NULL OR "userId" = app_current_user_id())', t);
    EXECUTE format('CREATE POLICY write_own ON %I FOR ALL
                      USING ("userId" = app_current_user_id())
                      WITH CHECK ("userId" = app_current_user_id())', t);
  END LOOP;
END $$;

-- Shared reference data (no tenant): read-only for app.
REVOKE INSERT, UPDATE, DELETE ON "Institution", "Security" FROM omniwealth_app;

-- WebhookEvent: written by ingress service only (separate role, no tenant context yet).
REVOKE ALL ON "WebhookEvent" FROM omniwealth_app;
GRANT SELECT, INSERT, UPDATE ON "WebhookEvent" TO omniwealth_worker;

-- ── Audit log: append-only + hash chain ─────────────────────────────────
-- Not FORCEd: the SECURITY DEFINER chain trigger (runs as table owner) must see the global tail hash.
-- The app/worker roles are not owners, so RLS still applies to them.
ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS audit_read_own ON "AuditLog";
DROP POLICY IF EXISTS audit_insert ON "AuditLog";
CREATE POLICY audit_read_own ON "AuditLog" FOR SELECT USING ("userId" = app_current_user_id());
CREATE POLICY audit_insert  ON "AuditLog" FOR INSERT
  WITH CHECK ("userId" IS NULL OR "userId" = app_current_user_id());

REVOKE UPDATE, DELETE, TRUNCATE ON "AuditLog" FROM PUBLIC, omniwealth_app, omniwealth_worker;

CREATE OR REPLACE FUNCTION audit_block_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'AuditLog is append-only (% blocked)', TG_OP USING ERRCODE = 'insufficient_privilege';
END $$;

DROP TRIGGER IF EXISTS audit_no_update ON "AuditLog";
CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON "AuditLog"
  FOR EACH ROW EXECUTE FUNCTION audit_block_mutation();
DROP TRIGGER IF EXISTS audit_no_truncate ON "AuditLog";
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON "AuditLog"
  FOR EACH STATEMENT EXECUTE FUNCTION audit_block_mutation();

-- Hash chain computed in-DB so the app can't forge it. Serialised by advisory lock.
CREATE OR REPLACE FUNCTION audit_chain() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE prev char(64);
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('auditlog_chain'));
  SELECT hash INTO prev FROM "AuditLog" ORDER BY id DESC LIMIT 1;
  NEW."prevHash" := prev;
  NEW.hash := encode(digest(
      coalesce(prev,'') || '|' || coalesce(NEW."userId"::text,'') || '|' || NEW."actorType" || '|' ||
      NEW.action::text || '|' || coalesce(NEW."targetType",'') || '|' || coalesce(NEW."targetId",'') || '|' ||
      coalesce(NEW.metadata::text,'') || '|' || NEW."createdAt"::text, 'sha256'), 'hex');
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS audit_hash ON "AuditLog";
CREATE TRIGGER audit_hash BEFORE INSERT ON "AuditLog"
  FOR EACH ROW EXECUTE FUNCTION audit_chain();

-- Verification query (run by compliance job):
--   SELECT id FROM (SELECT id, "prevHash", lag(hash) OVER (ORDER BY id) AS expected FROM "AuditLog") s
--   WHERE "prevHash" IS DISTINCT FROM expected;   -- must return 0 rows

-- ── Data-integrity guards ───────────────────────────────────────────────
ALTER TABLE "Transaction" DROP CONSTRAINT IF EXISTS txn_amount_positive;
ALTER TABLE "Transaction" ADD CONSTRAINT txn_amount_positive CHECK ("amountMinor" >= 0);
ALTER TABLE "Account" DROP CONSTRAINT IF EXISTS account_mask_len;
ALTER TABLE "Account" ADD CONSTRAINT account_mask_len CHECK (mask IS NULL OR mask ~ '^[0-9A-Za-z]{2,4}$');
ALTER TABLE "Connection" DROP CONSTRAINT IF EXISTS connection_token_encrypted;
ALTER TABLE "Connection" ADD CONSTRAINT connection_token_encrypted CHECK ("accessTokenCiphertext" LIKE 'v1:%');
