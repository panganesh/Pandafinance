# OmniWealth

Bank-grade personal finance & wealth management — one pane of glass for daily cashflow, multi-horizon goals, aggregated bank + brokerage accounts, and forward-looking insights.

| Deliverable | Where |
|---|---|
| 1. Database schema (Prisma, 20 models) | `prisma/schema.prisma` |
| — Row-Level Security, roles, immutable hash-chained audit log | `prisma/migrations/0001_rls/migration.sql` |
| — Tenant-isolation test | `prisma/tests/rls_test.sql` |
| 2. API specification (OpenAPI 3.1) | `api/openapi.yaml` |
| 3. Calculation engine & client state | `packages/engine/src` (tests in `packages/engine/test`) |
| 4. Dashboard UI blueprint (desktop + mobile) | `docs/UI_BLUEPRINT.md` |
| System architecture, security model, sync design | `docs/ARCHITECTURE.md` |

## Quick start

```bash
cd packages/engine
npm install
npm test          # 39 tests: pacing, net worth, compound, FIRE/Monte Carlo, goals,
                  # budgets, categorisation, recurring/anomaly, portfolio, sync backoff,
                  # AES-256-GCM token envelope, offline outbox
```

```ts
import { dailyPacing, simulateFire, calculateNetWorth } from "@omniwealth/engine";

dailyPacing({
  monthlyIncomeMinor: 12_000_000n,   // ₹1,20,000 in paise
  fixedExpensesMinor: 4_500_000n,
  savingsGoalsMinor: 3_000_000n,
  daysInMonth: 31, dayOfMonth: 25,
  spentBeforeTodayMinor: 3_400_000n, spentTodayMinor: 42_000n,
});
// → { baseDailyMinor: 145161n, adjustedDailyMinor: 157142n, status: "ON_TRACK", ... }
```

## Non-negotiables baked in

* Money is `bigint` minor units end to end; JSON carries it as strings.
* Aggregation is read-only: money-movement scopes are refused at link time.
* Provider tokens are envelope-encrypted (AES-256-GCM + KMS) and bound to their row.
* Every tenant table is behind forced RLS; no tenant context returns zero rows.
* Audit log is append-only and tamper-evident.
