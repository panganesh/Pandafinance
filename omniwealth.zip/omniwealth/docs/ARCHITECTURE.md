# OmniWealth — System Architecture

## 1. Topology

```
                    ┌─────────── Clients ────────────┐
                    │ Next.js 14 (web, BFF routes)   │
                    │ Expo / React Native (mobile)   │
                    └───────────────┬────────────────┘
                                    │ HTTPS (TLS 1.3, HSTS, cert pinning on mobile)
                     ┌──────────────▼──────────────┐
                     │ API Gateway / WAF           │  rate limit, bot mgmt, JWT verify
                     └──────┬───────────────┬──────┘
                            │               │
              ┌─────────────▼───┐     ┌─────▼──────────────┐
              │ Core API        │     │ Webhook Ingress    │  verifies signatures, dedupes,
              │ NestJS + TS     │     │ (stateless, tiny)  │  ACKs < 200 ms, enqueues
              └──┬──────┬───────┘     └─────┬──────────────┘
                 │      │                   │
     ┌───────────▼┐  ┌──▼────────┐   ┌──────▼─────────┐
     │ PostgreSQL │  │  Redis    │◀──│  Queue (BullMQ │
     │ 16 + RLS   │  │ cache, RL │   │  on Redis/SQS) │
     └─────▲──────┘  └───────────┘   └──────┬─────────┘
           │                                │
     ┌─────┴──────────────────────────────┐ │
     │ Workers: sync · categorise ·       │◀┘
     │ recurring/anomaly · snapshots ·    │──▶ Plaid · MX · Salt Edge · Account Aggregator
     │ prices/FX · Monte Carlo · OCR      │──▶ SnapTrade · Alpaca · price/FX feeds
     └────────────────────────────────────┘
           │
     ┌─────▼──────┐   ┌──────────────┐   ┌────────────────────┐
     │ S3 (SSE-KMS)│  │ KMS (KEK)    │   │ SIEM / WORM archive│
     │ receipts    │  │ token DEKs   │   │ audit log export   │
     └─────────────┘  └──────────────┘   └────────────────────┘
```

**Why this shape**
* Webhook ingress is a separate service so a burst from a provider can't starve user-facing API capacity, and so it can run with a role that only writes `WebhookEvent`.
* All finance maths lives in `@omniwealth/engine` (pure TS, no I/O), imported by API, workers, web and mobile → one source of truth, unit-tested in isolation.
* Workers run per-user inside a transaction with `app.current_user_id` set — RLS applies to background jobs too, not just HTTP.

## 2. Repository layout

```
omniwealth/
├── prisma/
│   ├── schema.prisma                 # 20 models, money as BigInt minor units
│   ├── migrations/0001_rls/          # RLS, roles, append-only hash-chained audit log
│   └── tests/rls_test.sql            # cross-tenant + audit tamper checks
├── api/openapi.yaml                  # OpenAPI 3.1, 33 paths / 43 operations
├── packages/engine/                  # calculation engine + client store (39 tests)
│   ├── src/{money,netWorth,pacing,compound,fire,goals,budget,
│   │        categorize,insights,portfolio,sync,crypto,store}.ts
│   └── test/engine.test.ts
└── docs/{ARCHITECTURE,UI_BLUEPRINT}.md
```

Suggested apps to add next (monorepo with pnpm + Turborepo): `apps/web` (Next.js), `apps/mobile` (Expo), `apps/api` (NestJS), `apps/webhooks`, `apps/workers`.

## 3. Aggregation design

### Provider abstraction
```ts
interface AggregationAdapter {
  createLinkSession(user, opts): Promise<LinkSession>;
  exchange(publicToken): Promise<{ accessToken; connectionId; scopes; institution }>;
  syncTransactions(conn, cursor): Promise<{ added; modified; removed; nextCursor }>;
  getBalances(conn): Promise<AccountBalance[]>;
  getHoldings?(conn): Promise<Holding[]>;
  verifyWebhook(headers, rawBody): Promise<VerifiedEvent>;
  revoke(conn): Promise<void>;
}
```
Adapters: `PlaidAdapter` (transactions/sync cursor API, investments), `AccountAggregatorAdapter` (RBI AA via an FIU TSP — consent artefact, FI data fetch, JWS-signed, decrypt with session ECDH keys), `SnapTradeAdapter` (brokerages incl. Zerodha / Upstox / IBKR), `SaltEdgeAdapter`, `MXAdapter`, `ManualAdapter`.

### Sync pipeline
1. **Trigger** — webhook (`SYNC_UPDATES_AVAILABLE`, AA `FI_READY`), schedule (every 6h, staggered by hash(userId)), or manual (token-bucket: ≤1 per 15 min per connection).
2. **Lock** — Redis `SET sync:{connId} NX PX 300000` prevents concurrent syncs of one connection.
3. **Fetch** — cursor-based incremental; providers throttled by a per-provider token bucket.
4. **Upsert** — idempotent on `(accountId, providerTransactionId)`; pending→posted reconciliation; removed → `REVERSED`.
5. **Enrich** — normalise merchant → rules engine → recurring/anomaly detection → FX to base currency.
6. **Derive** — refresh today's `NetWorthSnapshot`, re-evaluate affected goals and budgets.
7. **Notify** — publish `sync.completed` on the user's SSE channel → clients invalidate queries.
8. **Audit** — `SYNC_SUCCEEDED/FAILED` with counts (never payloads).

### Failure handling (`engine/src/sync.ts`)
| Class | Examples | Behaviour |
|---|---|---|
| REAUTH | `ITEM_LOGIN_REQUIRED`, `CONSENT_EXPIRED` | Status `NEEDS_REAUTH`, **no auto-retry** (avoids bank lockouts), push + in-app banner, update-mode link. |
| MFA | `INVALID_MFA`, `ITEM_LOCKED` | Status `MFA_REQUIRED`, user-driven only. |
| RATE_LIMIT | `429`, `RATE_LIMIT_EXCEEDED` | Honour `Retry-After`, else backoff. |
| TRANSIENT | `INSTITUTION_DOWN`, 5xx, timeouts | Exponential backoff, full jitter, base 30s, cap 6h, max 8 attempts → park + ops alert. |
| FATAL | everything else | Park, alert, no retry. |

Consent expiry is tracked (`consentExpiresAt`); users are prompted 7 days before AA consent or Plaid `PENDING_EXPIRATION`.

## 4. Security model

| Control | Implementation |
|---|---|
| AuthN | OIDC (Auth0/Cognito/Keycloak) with PKCE; passkeys/TOTP MFA; BFF keeps tokens in `HttpOnly; Secure; SameSite=Strict` cookies; refresh rotation with reuse detection. Step-up auth for export/delete/new connection. |
| AuthZ / tenancy | Postgres RLS on every tenant table, `FORCE`d so even the table owner is subject to it; app role is `NOBYPASSRLS`; tenant id set with transaction-local `set_config` (safe with PgBouncer transaction pooling). No tenant context ⇒ zero rows. Verified by `prisma/tests/rls_test.sql`. |
| Secrets at rest | Provider access tokens: AES-256-GCM envelope encryption, per-token DEK wrapped by KMS KEK, AAD = `userId|connectionId` so ciphertext can't be replayed across rows. DB check constraint rejects non-`v1:` (plaintext) tokens. Full-disk + RDS encryption underneath; receipts in S3 with SSE-KMS and pre-signed, 5-minute URLs. |
| Read-only guarantee | Only read products requested at link time; `assertReadOnlyScopes` rejects any granted scope matching transfer/payment/trade; no code path calls provider money-movement APIs; egress allow-list on workers. |
| Data minimisation | Account `mask` max 4 chars; no credentials ever stored (provider-hosted link flows); IPs stored as HMAC. |
| Audit | `AuditLog` append-only (UPDATE/DELETE/TRUNCATE revoked **and** trigger-blocked), SHA-256 hash chain computed in-DB, nightly export to S3 Object Lock (compliance mode) + SIEM. Chain verification query in the migration. |
| Webhooks | Signature verification (Plaid JWT/ES256 + body hash; HMAC for SnapTrade; JWS for AA), 5-min timestamp window, dedupe on `(provider, providerEventId)`, raw body persisted before processing. |
| App security | Strict CSP with nonces, no third-party scripts on authenticated pages, Zod validation on every input, Idempotency-Key on mutations, per-user + per-IP rate limits in Redis, OWASP ASVS L2 as the baseline. |
| Mobile | Certificate pinning, biometric app lock, `FLAG_SECURE`, jailbreak/root signals feed risk scoring (not hard block). |
| Compliance targets | SOC 2 Type II, ISO 27001; India: DPDP Act 2023 (consent, erasure, breach notice), RBI AA ecosystem rules as FIU; US: GLBA Safeguards, CCPA; EU: GDPR. Data residency: India users in ap-south-1. |

## 5. Calculation engine contract

All ledger money is `bigint` minor units — no floats in balances, budgets, or allowances. Floats are used only inside forward projections (compound, Monte Carlo), converted back at the boundary.

| Function | Formula / behaviour |
|---|---|
| `dailyPacing` | `base = ⌊(income − fixed − savings) / daysInMonth⌋`; `adjusted = ⌊(disposable − spentBeforeToday) / daysRemaining⌋` so overspend shrinks future days; status vs straight-line pace ±10%. Uses the user's local calendar day (`localDateParts`). |
| `calculateNetWorth` | Σ assets − Σ liabilities in base currency via single-rounding FX pivot; overpaid cards count as cash; per-class breakdown from holdings; stale-balance detection (48h). |
| `projectCompound` | Monthly compounding at the effective monthly rate `(1+r)^(1/12) − 1`, SIP step-up, inflation-adjusted series. |
| `requiredMonthlyContribution` | PMT: `(FV − PV·(1+r)^n)·r / ((1+r)^n − 1)`, ceiling-rounded so it never under-asks. |
| `simulateFire` | FIRE number = expenses / SWR; deterministic years-to-FI in real terms; Monte Carlo with lognormal returns (moment-matched to mean/vol), seeded PRNG for reproducibility; p10/p50/p90 per year. |
| `allocateSurplus` | Waterfall: reserved % per goal → this month's required contribution by priority/date → top-up by priority. |
| `categorize` | User rules → system rules → MCC → keyword heuristics → provider category; ReDoS-guarded user regexes. |
| `detectRecurring` / `detectAnomalies` | Median cadence snapped to 7/14/30/91/182/365 with ≥70% agreement and stable amounts; robust z-score (MAD) > 3.5. |
| `summarizePortfolio`, `modifiedDietz`, `xirr`, `realizeFifo` | Unrealised/realised PnL, day delta, allocation, dividend yield, flow-neutral return for benchmark comparison, XIRR by bisection, FIFO lots. |

## 6. Operational targets

| SLO | Target |
|---|---|
| API p95 latency (reads) | < 250 ms |
| Webhook ACK | < 200 ms p99 |
| Webhook → data visible | < 60 s p95 |
| Availability | 99.9% monthly |
| RPO / RTO | 5 min (PITR) / 1 h |

Observability: OpenTelemetry traces across API → queue → worker → provider; per-provider error-rate dashboards; alert when any institution's sync failure rate > 20% over 15 min (usually an institution outage — show a status banner instead of paging users individually).

## 7. Running the verification locally

```bash
cd packages/engine && npm install && npm test            # 39 engine tests
npx prisma validate && npx prisma migrate dev            # creates tables
psql "$DATABASE_URL" -f prisma/migrations/0001_rls/migration.sql
psql "$DATABASE_URL" -f prisma/tests/rls_test.sql        # isolation & audit checks
npx @redocly/cli lint api/openapi.yaml
```
