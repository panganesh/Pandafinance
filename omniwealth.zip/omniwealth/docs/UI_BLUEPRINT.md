# OmniWealth — Dashboard UI Blueprint

Stack: Next.js 14 App Router · Tailwind · shadcn/ui · Lucide · Recharts (web) / Expo Router + Victory Native (mobile).
Both clients consume `@omniwealth/engine`, so every number on screen is computed by the same code the API uses.

---

## 1. Design principles

| Principle | What it means on screen |
|---|---|
| **One number first** | Every screen leads with a single answer: *"₹1,420 left to spend today"*, *"Net worth ₹48.2L ▲ 1.8%"*. Detail is one tap away, never in the way. |
| **Forward, not backward** | Lead with what you can still do (remaining, pace, projected date) rather than what you've spent. |
| **Calm by default** | Neutral palette; colour is reserved for state (green on track, amber at risk, red over). No red unless action is needed. |
| **Trust signals visible** | Every balance shows freshness ("synced 4 min ago"); stale/broken connections surface as a banner with a one-tap fix. |
| **Privacy mode** | Eye toggle blurs all amounts (`blur-sm` + `aria-hidden` swap) — for checking the app on the metro. |
| **Accessible** | WCAG 2.2 AA contrast; status never by colour alone (icon + label); amounts announced in full by screen readers ("one thousand four hundred twenty rupees"). |

---

## 2. Information architecture

```
/                       Today (home)        ← default landing
/cashflow               Transactions · Budgets · Subscriptions · Forecast
/goals                  Monthly · Yearly · Lifetime (FIRE)
/wealth                 Net worth · Portfolio · Holdings · Allocation
/accounts               Connections & health · Manual accounts
/settings               Profile · Security & sessions · Audit log · Data export/delete
```

Mobile bottom tab bar: **Today · Cashflow · ➕ · Goals · Wealth** (centre ➕ = Quick-add; Accounts/Settings live under the avatar).
Desktop: collapsible left sidebar (same 5 + Accounts, Settings), command palette `⌘K` for "add expense", "find Swiggy", "go to FIRE".

---

## 3. Desktop — Today dashboard (≥1280px, 12-col grid)

```
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│ ◧ OmniWealth   🔍 Search / ⌘K                          ⟳ Synced 4m ago   👁   🔔 2   (A) │
├────────┬─────────────────────────────────────────────────────────────────────────────────┤
│ Today  │ ⚠ HDFC Bank needs re-authorisation — balances paused since 22 Oct  [Reconnect] │  ← only when needed
│Cashflow├───────────────────────────────┬───────────────────────────┬─────────────────────┤
│ Goals  │ SAFE TO SPEND TODAY           │ NET WORTH                 │ THIS MONTH          │
│ Wealth │ ₹1,420                        │ ₹48,21,560  ▲ ₹86,400 30d │ Spent  ₹22,340      │
│Accounts│ of ₹1,500 · 20 days left      │ ╱╲__╱‾‾╲_╱‾‾ (sparkline)  │ Left   ₹17,660      │
│Settings│ ▓▓▓▓▓▓▓▓▓░  ● Ahead of pace   │ Assets 52.9L · Debt 4.7L  │ ◔ 56% · on pace     │
│        │ [+ Add expense]               │                           │                     │
│        ├───────────────────────────────┴───────────────────────────┴─────────────────────┤
│        │ BUDGET ENVELOPES                                     50/30/20 ▾   [Edit budget] │
│        │ Dining     ▓▓▓▓▓▓▓░░░  ₹4,100 / 6,000   ● On pace                               │
│        │ Groceries  ▓▓▓▓▓▓▓▓▓░  ₹7,900 / 8,000   ▲ Over pace                             │
│        │ Leisure    ▓▓░░░░░░░░  ₹  800 / 4,000   ● Under                                 │
│        ├──────────────────────────────────────────┬──────────────────────────────────────┤
│        │ GOALS                                    │ PORTFOLIO TODAY                      │
│        │ Emergency fund  ▓▓▓▓▓▓░░ 68% · Mar '27 ✓ │ ₹31.4L   ▲ ₹12,830 (+0.41%)          │
│        │ Goa trip        ▓▓▓░░░░░ 35% · at risk ! │ vs Nifty 50  +0.22%  → α +0.19%      │
│        │ FIRE @ 45       ▓▓░░░░░░ 22% · 78% prob. │ Equity 72 · Debt 18 · Gold 6 · Cash 4│
│        │ [View all goals]                         │ [Holdings]                           │
│        ├──────────────────────────────────────────┴──────────────────────────────────────┤
│        │ RECENT ACTIVITY                                          INSIGHTS               │
│        │ Today  Swiggy          Dining      −₹  420  │ 💡 Netflix went up 8% (₹649→₹699)  │
│        │ Today  BESCOM          Utilities   −₹1,860  │ 💡 3 subscriptions unused 60+ days │
│        │ Yest.  Salary Acme     Income   +₹1,20,000  │ ⚠ ₹18,400 at Croma is 6× usual     │
│        │ [All transactions]                          │ [Review]                           │
└────────┴─────────────────────────────────────────────┴────────────────────────────────────┘
```

**Hierarchy:** Row 1 = the three questions users open the app to answer (Can I spend? Am I richer? How's the month?). Row 2 = where the money's going. Row 3 = where it's growing. Row 4 = what changed & what to do.

---

## 4. Mobile — Today (375–430px, single column)

```
┌──────────────────────────────┐
│ Good morning, Asha     👁 (A)│
│ ⚠ HDFC needs reconnect  ›    │
├──────────────────────────────┤
│   SAFE TO SPEND TODAY        │
│        ₹1,420                │   ← 48px, tabular numerals
│   ◯◯◯◯◯◯◯◯◯◔  ring 95%       │
│   20 days left · Ahead       │
├──────────────────────────────┤
│ Net worth  ₹48.2L  ▲1.8%   › │   ← tappable summary rows
│ This month ₹17.6k left     › │
│ Portfolio  ▲ ₹12.8k today  › │
├──────────────────────────────┤
│ GOALS          ← swipe →     │
│ ┌──────┐ ┌──────┐ ┌──────┐   │
│ │EF 68%│ │Goa35%│ │FIRE  │   │
│ │ ✓    │ │ !    │ │78%   │   │
│ └──────┘ └──────┘ └──────┘   │
├──────────────────────────────┤
│ Today                        │
│ 🍔 Swiggy        −₹420       │
│ ⚡ BESCOM      −₹1,860       │
├──────────────────────────────┤
│  Today  Cash  [ ➕ ]  Goals  Wealth │
└──────────────────────────────┘
```

**Quick-add sheet (➕):** opens as bottom sheet with numeric keypad focused immediately → amount → merchant (autocomplete from history) → category chip (pre-selected by rule engine) → 📷 receipt → **Save**. Target: logged in under 5 seconds. Works offline: saved to the outbox, shown with a ⏱ badge until synced; daily allowance updates instantly.

**Gestures:** swipe left on a transaction → recategorise; swipe right → mark as transfer/split. Pull-to-refresh triggers `/connections/{id}/sync` (rate-limited, shows "next refresh in 12 min" if throttled).

---

## 5. Key secondary screens

| Screen | Lead element | Supporting |
|---|---|---|
| **Cashflow › Budgets** | Method switcher (Zero-based / 50·30·20 / Envelope). Zero-based shows a sticky "₹0 left to assign" counter that must hit zero. | Drag to reallocate between envelopes; rollover toggle per envelope. |
| **Cashflow › Subscriptions** | Monthly total of recurring charges | List with cadence, next date, price-change badges, "last used" if detectable; one-tap "remind me to cancel". |
| **Cashflow › Forecast** | 90-day balance line with lowest-point marker ("Lowest: ₹8,200 on 3 Dec") | Upcoming bills timeline. |
| **Goals › Lifetime (FIRE)** | Fan chart (p10/p50/p90 bands) with FI age marker and success probability | Sliders: savings rate, retirement age, expected return, SWR, inflation — recompute client-side with the engine (debounced 150ms, 2k runs); "Save scenario" persists to goal `params`. |
| **Goals › detail** | Progress ring + projected completion date | Required vs planned monthly contribution; auto-allocation % slider; contribution history. |
| **Wealth › Net worth** | Stacked area by asset class over time | Assets/liabilities breakdown, stale-account chips. |
| **Wealth › Portfolio** | Value + day delta + benchmark toggle (Nifty 50 / Sensex / S&P 500) | Allocation donut, holdings table (sortable: value, day %, unrealised %, yield), realised vs unrealised PnL, XIRR. Tax-loss harvest candidates (informational). |
| **Accounts** | Connection health list: ● Active / ⚠ Needs reauth / ⏱ Retrying in 4m | Re-auth CTA opens provider update mode; disconnect revokes at provider. |
| **Settings › Security** | Active sessions with device & location; "sign out everywhere" | MFA enrolment, audit log (user-visible slice), data export, delete account. |

---

## 6. Component map (shadcn/ui + custom)

| Component | Built from | Notes |
|---|---|---|
| `<MoneyText amount currency size privacy />` | span | `font-variant-numeric: tabular-nums`; Indian grouping (₹12,34,567) via `Intl` en-IN; lakh/crore compact mode (₹48.2L); blur in privacy mode. |
| `<StatCard>` | Card | Title, hero `MoneyText`, delta chip, sparkline slot, footer CTA. |
| `<PaceBar>` | Progress | Two layers: spent, and a tick at "expected by today". Colour from `paceStatus`. |
| `<EnvelopeRow>` | custom | Category icon, bar, `spent / available`, status badge. |
| `<GoalRing>` | SVG | Progress ring + status icon; tap → detail. |
| `<FanChart>` | Recharts Area ×3 | p10–p90 band, p50 line, FI-age reference line. |
| `<ConnectionBanner>` | Alert | Driven by connections with `NEEDS_REAUTH` / `MFA_REQUIRED`; dismissible per session only. |
| `<QuickAddSheet>` | Sheet (web) / BottomSheet (mobile) | Keypad, merchant combobox, category chips, receipt upload (pre-signed URL), offline outbox. |
| `<FreshnessTag>` | Badge | "synced 4m ago" / "stale 3d" with tooltip linking to account health. |
| `<InsightCard>` | Card | Typed: price-change, anomaly, unused subscription, goal-at-risk; each with one primary action. |

---

## 7. Data flow & state

```
          SSE /events (sync.completed, txn.created, connection.status)
                         │ invalidate
┌─────────────┐   ┌──────▼──────────────┐   ┌─────────────────────────────┐
│  REST API   │──▶│ TanStack Query cache │──▶│ engine selectors (memoised) │──▶ UI
└─────────────┘   └──────────────────────┘   │ selectNetWorth, selectPacing│
       ▲                                      └──────────────▲──────────────┘
       │ POST /transactions/batch (idempotent)                │
┌──────┴───────────────────────┐                              │
│ Offline outbox (IndexedDB /  │──── optimistic merge ────────┘
│ MMKV) — clientMutationId     │
└──────────────────────────────┘
```

* Server components render the shell and first paint of Today (no client-side waterfall); balances hydrate into the Query cache.
* `staleTime`: balances 60s, transactions 30s, holdings 5 min during market hours / 1h otherwise.
* Tokens never touch JS: BFF sets `HttpOnly` cookies; API calls go through Next.js route handlers.
* Mobile: biometric unlock (Face ID / fingerprint) gates the app on resume after 5 min; screenshots blocked on sensitive screens (Android `FLAG_SECURE`, iOS snapshot blur).

---

## 8. Onboarding (activation funnel)

1. **Sign in** (OIDC: Google / Apple / email magic link) → enrol passkey or TOTP.
2. **3 numbers** — monthly take-home, fixed bills, savings target → instantly shows *Safe to spend today* (value before any bank link).
3. **Link first account** — explain read-only in one line + lock icon ("We can see, never move, your money"). AA consent for India; Plaid/SnapTrade elsewhere.
4. **First insight within 60s** of sync — e.g. detected subscriptions total.
5. **Pick one goal** from templates (Emergency fund pre-filled at 6× fixed bills).

Activation metric: user sees a personalised daily allowance **and** one goal within the first session.

---

## 9. Empty, loading and error states

| State | Treatment |
|---|---|
| Loading | Skeletons matching final layout; hero number skeleton keeps width to avoid layout shift. |
| No accounts yet | Today still works from profile numbers; cards show "Link an account to track this automatically". |
| Sync retrying | Amber `FreshnessTag` "Retrying in 4m" — no modal. |
| Needs re-auth / MFA | Persistent banner + push notification; never auto-retried (protects bank login from lockout). |
| Offline | Top toast "Offline — changes will sync"; Quick-add fully functional; outbox count badge. |
