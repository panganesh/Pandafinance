/**
 * Client state management.
 *
 * Split of responsibilities (used by both Next.js web and Expo mobile):
 *   • Server state (accounts, transactions, holdings) → TanStack Query, keyed by resource, with
 *     webhook-driven invalidation over SSE/WebSocket (`sync.completed` → invalidate ['accounts'], ['transactions']).
 *   • Derived finance state (net worth, pacing, goal status) → pure selectors below, memoised, so web,
 *     mobile, and the server compute identical numbers from the same engine.
 *   • Local UI + offline state → this tiny framework-agnostic store (a Zustand-compatible API surface).
 *
 * The offline outbox persists manual quick-adds (IndexedDB on web, SQLite/MMKV on mobile) and replays
 * them idempotently via POST /transactions/batch using clientMutationId.
 */
import { calculateNetWorth, AccountBalance, NetWorthResult } from "./netWorth.js";
import { dailyPacing, PacingResult } from "./pacing.js";
import type { FxTable, Minor } from "./money.js";

type Listener<T> = (state: T, prev: T) => void;

export interface Store<T> {
  getState(): T;
  setState(partial: Partial<T> | ((s: T) => Partial<T>)): void;
  subscribe(l: Listener<T>): () => void;
}

export function createStore<T extends object>(initial: T): Store<T> {
  let state = initial;
  const listeners = new Set<Listener<T>>();
  return {
    getState: () => state,
    setState(partial) {
      const prev = state;
      const patch = typeof partial === "function" ? partial(state) : partial;
      state = Object.freeze({ ...state, ...patch }) as T;
      listeners.forEach((l) => l(state, prev));
    },
    subscribe(l) { listeners.add(l); return () => listeners.delete(l); },
  };
}

/** Memoise a selector on reference equality of its inputs. */
export function memoSelector<I extends unknown[], O>(inputs: (s: AppState) => I, compute: (...args: I) => O) {
  let lastIn: I | null = null;
  let lastOut: O;
  return (s: AppState): O => {
    const next = inputs(s);
    if (lastIn && next.length === lastIn.length && next.every((v, i) => Object.is(v, lastIn![i]))) return lastOut;
    lastIn = next;
    lastOut = compute(...next);
    return lastOut;
  };
}

// ───────────────────────── App state ─────────────────────────

export interface PendingMutation {
  clientMutationId: string;
  payload: {
    accountId: string; direction: "DEBIT" | "CREDIT"; amountMinor: string; currency: string;
    occurredAt: string; merchantName?: string; categoryId?: string; notes?: string; receiptId?: string;
  };
  attempts: number;
  lastError?: string;
  createdAt: string;
}

export interface AppState {
  baseCurrency: string;
  timezone: string;
  fx: FxTable;
  accounts: AccountBalance[];
  profile: { monthlyIncomeMinor: Minor; fixedExpensesMinor: Minor; savingsGoalsMinor: Minor } | null;
  /** Discretionary spend this month, by local date "YYYY-MM-DD". */
  spendByDay: Record<string, Minor>;
  today: { year: number; month: number; day: number; daysInMonth: number };
  outbox: PendingMutation[];
  online: boolean;
  privacyMode: boolean;     // blur balances (shoulder-surfing protection)
}

export const selectNetWorth = memoSelector(
  (s: AppState) => [s.accounts, s.baseCurrency, s.fx] as [AccountBalance[], string, FxTable],
  (accounts, baseCurrency, fx): NetWorthResult => calculateNetWorth(accounts, { baseCurrency, fx }),
);

export const selectPacing = memoSelector(
  (s: AppState) => [s.profile, s.spendByDay, s.today, s.outbox] as const as
    [AppState["profile"], AppState["spendByDay"], AppState["today"], PendingMutation[]],
  (profile, spendByDay, today, outbox): PacingResult | null => {
    if (!profile) return null;
    const key = (d: number) => `${today.year}-${String(today.month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    let before = 0n;
    for (let d = 1; d < today.day; d++) before += spendByDay[key(d)] ?? 0n;
    // Optimistic: offline debits logged today count immediately.
    const pendingToday = outbox
      .filter((m) => m.payload.direction === "DEBIT" && m.payload.occurredAt.startsWith(key(today.day)))
      .reduce((a, m) => a + BigInt(m.payload.amountMinor), 0n);
    return dailyPacing({
      monthlyIncomeMinor: profile.monthlyIncomeMinor,
      fixedExpensesMinor: profile.fixedExpensesMinor,
      savingsGoalsMinor: profile.savingsGoalsMinor,
      daysInMonth: today.daysInMonth,
      dayOfMonth: today.day,
      spentBeforeTodayMinor: before,
      spentTodayMinor: (spendByDay[key(today.day)] ?? 0n) + pendingToday,
    });
  },
);

// ───────────────────────── Offline outbox ─────────────────────────

export interface BatchResult { clientMutationId: string; status: number; transactionId?: string }
export type BatchSender = (mutations: PendingMutation[]) => Promise<BatchResult[]>;

export function enqueueQuickAdd(store: Store<AppState>, payload: PendingMutation["payload"], uuid: () => string, now = new Date()) {
  const m: PendingMutation = { clientMutationId: uuid(), payload, attempts: 0, createdAt: now.toISOString() };
  store.setState((s) => ({ outbox: [...s.outbox, m] }));
  return m.clientMutationId;
}

/**
 * Flush outbox. 2xx (incl. 200 idempotent replay) → remove. 4xx (validation) → drop & surface.
 * 5xx / network → keep for next flush. Returns ids that were rejected permanently.
 */
export async function flushOutbox(store: Store<AppState>, send: BatchSender, maxBatch = 200): Promise<string[]> {
  const { outbox, online } = store.getState();
  if (!online || outbox.length === 0) return [];
  const batch = outbox.slice(0, maxBatch);
  let results: BatchResult[];
  try {
    results = await send(batch);
  } catch (e) {
    store.setState((s) => ({
      outbox: s.outbox.map((m) => batch.some((b) => b.clientMutationId === m.clientMutationId)
        ? { ...m, attempts: m.attempts + 1, lastError: String(e) } : m),
    }));
    return [];
  }
  const byId = new Map(results.map((r) => [r.clientMutationId, r]));
  const rejected: string[] = [];
  store.setState((s) => ({
    outbox: s.outbox.flatMap((m) => {
      const r = byId.get(m.clientMutationId);
      if (!r) return [m];
      if (r.status >= 200 && r.status < 300) return [];
      if (r.status >= 400 && r.status < 500) { rejected.push(m.clientMutationId); return []; }
      return [{ ...m, attempts: m.attempts + 1, lastError: `HTTP ${r.status}` }];
    }),
  }));
  return rejected;
}
