import { abs, Minor } from "./money.js";

export type Direction = "DEBIT" | "CREDIT";
export type CategorySource = "PROVIDER" | "RULE" | "ML" | "USER";

export interface TxnForCategorization {
  rawDescription: string;
  merchantName?: string | null;
  mcc?: string | null;
  amountMinor: Minor;
  direction: Direction;
  providerCategory?: string | null; // e.g. Plaid personal_finance_category.primary
}

export interface CategoryRule {
  id: string;
  userId: string | null;  // null = system
  priority: number;       // lower first
  merchantPattern?: string;
  descriptionPattern?: string;
  mccCodes?: string[];
  minAmountMinor?: Minor;
  maxAmountMinor?: Minor;
  direction?: Direction;
  categorySlug: string;
  markAsTransfer?: boolean;
}

export interface CategorizationResult {
  categorySlug: string;
  source: CategorySource;
  confidence: number;
  isTransfer: boolean;
  ruleId?: string;
}

/** Strip noise so "SWIGGY*ORDER 8812 BLR" and "Swiggy Bangalore" collapse to "swiggy". */
export function normalizeMerchant(s: string): string {
  return s
    .toLowerCase()
    .replace(/^(upi|pos|ach|neft|imps|rtgs|nach|ecom|vps)[\s/\-:*]+/g, "")
    .replace(/[*#].*$/, "")
    .replace(/\b(pvt|ltd|llc|inc|india|bangalore|bengaluru|mumbai|pune|delhi|blr|com|www)\b/g, "")
    .replace(/\d{3,}/g, "")
    .replace(/[^a-z\s&]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .slice(0, 3)
    .join(" ");
}

const MCC_MAP: Record<string, string> = {
  "5411": "food.groceries", "5812": "food.dining", "5814": "food.dining",
  "4900": "utilities.electricity", "4814": "utilities.telecom", "4899": "subscriptions",
  "5541": "transport.fuel", "4121": "transport.rideshare", "4111": "transport.transit",
  "7832": "leisure.entertainment", "5815": "subscriptions", "5817": "subscriptions",
  "6513": "housing.rent", "8062": "health.medical", "5912": "health.pharmacy",
  "4511": "travel.flights", "7011": "travel.lodging", "5311": "shopping.general",
};

const KEYWORDS: [RegExp, string, boolean?][] = [
  [/\b(emi|loan|bajaj fin|hdfc ltd|home loan|auto ?debit loan)\b/i, "debt.emi"],
  [/\b(rent|nobroker|housing\.com)\b/i, "housing.rent"],
  [/\b(netflix|spotify|prime video|hotstar|youtube premium|icloud|google one|chatgpt|claude)\b/i, "subscriptions"],
  [/\b(swiggy|zomato|eatsure|dominos|starbucks|mcdonald)\b/i, "food.dining"],
  [/\b(bigbasket|blinkit|zepto|dmart|instamart|more retail)\b/i, "food.groceries"],
  [/\b(bescom|tata power|adani electricity|msedcl|electricity)\b/i, "utilities.electricity"],
  [/\b(airtel|jio|vodafone|vi postpaid|act fibernet|broadband)\b/i, "utilities.telecom"],
  [/\b(uber|ola|rapido|namma yatri)\b/i, "transport.rideshare"],
  [/\b(sip|zerodha|groww|kuvera|coin by zerodha|mutual fund)\b/i, "savings.investments", true],
  [/\b(salary|payroll|sal cr)\b/i, "income.salary"],
  [/\b(self transfer|own account|card payment|cc payment|credit card bill)\b/i, "transfer", true],
];

function safeRegex(p: string): RegExp | null {
  // User-supplied patterns: bounded length and no nested quantifiers to avoid ReDoS.
  if (p.length > 200 || /(\(.*[+*].*\))[+*]/.test(p)) return null;
  try { return new RegExp(p, "i"); } catch { return null; }
}

function ruleMatches(r: CategoryRule, t: TxnForCategorization, merchantNorm: string): boolean {
  if (r.direction && r.direction !== t.direction) return false;
  const amt = abs(t.amountMinor);
  if (r.minAmountMinor !== undefined && amt < r.minAmountMinor) return false;
  if (r.maxAmountMinor !== undefined && amt > r.maxAmountMinor) return false;
  if (r.mccCodes?.length && !(t.mcc && r.mccCodes.includes(t.mcc))) return false;
  if (r.merchantPattern) {
    const re = safeRegex(r.merchantPattern);
    if (!re || !(re.test(merchantNorm) || re.test(t.merchantName ?? ""))) return false;
  }
  if (r.descriptionPattern) {
    const re = safeRegex(r.descriptionPattern);
    if (!re || !re.test(t.rawDescription)) return false;
  }
  return Boolean(r.merchantPattern || r.descriptionPattern || r.mccCodes?.length || r.minAmountMinor !== undefined);
}

/**
 * Precedence: user rules → system rules → MCC → keyword heuristics → provider category → uncategorized.
 * (An ML classifier can slot in before provider category; its output uses source "ML".)
 */
export function categorize(t: TxnForCategorization, rules: CategoryRule[]): CategorizationResult {
  const merchantNorm = normalizeMerchant(t.merchantName || t.rawDescription);
  const ordered = [...rules].sort((a, b) =>
    (a.userId ? 0 : 1) - (b.userId ? 0 : 1) || a.priority - b.priority);

  for (const r of ordered) {
    if (ruleMatches(r, t, merchantNorm)) {
      return {
        categorySlug: r.categorySlug, source: r.userId ? "USER" : "RULE",
        confidence: r.userId ? 1 : 0.95, isTransfer: Boolean(r.markAsTransfer), ruleId: r.id,
      };
    }
  }
  if (t.mcc && MCC_MAP[t.mcc]) {
    return { categorySlug: MCC_MAP[t.mcc]!, source: "RULE", confidence: 0.85, isTransfer: false };
  }
  const hay = `${t.merchantName ?? ""} ${t.rawDescription}`;
  for (const [re, slug, transfer] of KEYWORDS) {
    if (re.test(hay)) return { categorySlug: slug, source: "RULE", confidence: 0.75, isTransfer: Boolean(transfer) };
  }
  if (t.providerCategory) {
    return { categorySlug: t.providerCategory.toLowerCase(), source: "PROVIDER", confidence: 0.6, isTransfer: /transfer/i.test(t.providerCategory) };
  }
  return {
    categorySlug: t.direction === "CREDIT" ? "income.other" : "uncategorized",
    source: "RULE", confidence: 0.2, isTransfer: false,
  };
}
