import { divRound, Minor, sum } from "./money.js";

export type Bucket = "NEEDS" | "WANTS" | "SAVINGS";
export type BudgetMethod = "ZERO_BASED" | "FIFTY_THIRTY_TWENTY" | "ENVELOPE" | "CUSTOM";

export interface BudgetLineInput {
  key: string;              // categoryId or bucket
  bucket?: Bucket;
  allocatedMinor: Minor;
  carriedInMinor?: Minor;   // envelope rollover
}

export class BudgetValidationError extends Error {}

/** Zero-based: every rupee of income must be assigned a job. */
export function validateZeroBased(incomeMinor: Minor, lines: BudgetLineInput[]): void {
  const allocated = sum(lines.map((l) => l.allocatedMinor));
  if (allocated !== incomeMinor) {
    const diff = incomeMinor - allocated;
    throw new BudgetValidationError(
      diff > 0n ? `Unassigned income remaining: ${diff}` : `Over-allocated by ${-diff}`);
  }
  if (lines.some((l) => l.allocatedMinor < 0n)) throw new BudgetValidationError("Negative allocation");
}

/** 50/30/20 split; rounding remainder goes to SAVINGS so the total is exact. */
export function fiftyThirtyTwenty(incomeMinor: Minor, split = { needs: 50, wants: 30, savings: 20 }): Record<Bucket, Minor> {
  if (split.needs + split.wants + split.savings !== 100) throw new BudgetValidationError("Split must total 100");
  const needs = divRound(incomeMinor * BigInt(split.needs), 100n);
  const wants = divRound(incomeMinor * BigInt(split.wants), 100n);
  return { NEEDS: needs, WANTS: wants, SAVINGS: incomeMinor - needs - wants };
}

export type PaceStatus = "UNDER" | "ON_PACE" | "OVER";

export interface LineStatus {
  key: string;
  availableMinor: Minor;   // allocated + carried in
  spentMinor: Minor;
  remainingMinor: Minor;
  expectedByNowMinor: Minor;
  pctUsed: number;
  paceStatus: PaceStatus;
  overBudget: boolean;
}

/**
 * Live status per line. `elapsedFraction` = elapsed days / days in period (0..1).
 * OVER  = already above the full allocation or > 110% of linear pace.
 */
export function budgetStatus(
  lines: BudgetLineInput[], spentByKey: Record<string, Minor>, elapsedFraction: number,
): LineStatus[] {
  const f = Math.min(1, Math.max(0, elapsedFraction));
  const fScaled = BigInt(Math.round(f * 10_000));
  return lines.map((l) => {
    const available = l.allocatedMinor + (l.carriedInMinor ?? 0n);
    const spent = spentByKey[l.key] ?? 0n;
    const expected = divRound(available * fScaled, 10_000n);
    const over = spent > available;
    let pace: PaceStatus;
    if (over || spent * 100n > expected * 110n) pace = "OVER";
    else if (spent * 100n < expected * 90n) pace = "UNDER";
    else pace = "ON_PACE";
    return {
      key: l.key,
      availableMinor: available,
      spentMinor: spent,
      remainingMinor: available - spent,
      expectedByNowMinor: expected,
      pctUsed: available === 0n ? (spent > 0n ? 100 : 0) : Number((spent * 10_000n) / available) / 100,
      paceStatus: pace,
      overBudget: over,
    };
  });
}

/** Envelope rollover into next period. Overspend can optionally be carried as a negative. */
export function rollover(statuses: LineStatus[], carryNegative = false): Record<string, Minor> {
  const out: Record<string, Minor> = {};
  for (const s of statuses) out[s.key] = carryNegative ? s.remainingMinor : (s.remainingMinor > 0n ? s.remainingMinor : 0n);
  return out;
}
