import { fromFloat, Minor, toFloat } from "./money.js";

/** Deterministic, seedable PRNG (mulberry32) — reproducible simulations for audit & tests. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Standard normal via Box–Muller. */
export function gaussian(rand: () => number): () => number {
  let spare: number | null = null;
  return () => {
    if (spare !== null) { const s = spare; spare = null; return s; }
    let u = 0, v = 0;
    while (u === 0) u = rand();
    while (v === 0) v = rand();
    const mag = Math.sqrt(-2 * Math.log(u));
    spare = mag * Math.sin(2 * Math.PI * v);
    return mag * Math.cos(2 * Math.PI * v);
  };
}

export interface FireInput {
  currentAge: number;
  currentPortfolioMinor: Minor;
  annualExpensesMinor: Minor;     // in today's money
  annualSavingsMinor: Minor;      // in today's money, assumed to grow with inflation
  expectedReturnBps?: number;     // nominal arithmetic mean, default 10%
  volatilityBps?: number;         // annual stdev, default 16%
  inflationBps?: number;          // default 6%
  swrBps?: number;                // default 4%
  /** If omitted, the deterministic FI age is used as the retirement age in simulation. */
  retirementAge?: number;
  lifeExpectancy?: number;        // default 90
  runs?: number;                  // default 2000
  seed?: number;
}

export interface FireResult {
  fireNumberMinor: Minor;
  /** Deterministic years to FI at expected real return; null if not reached by age 100. */
  yearsToFI: number | null;
  fiAge: number | null;
  retirementAgeUsed: number;
  successProbability: number;     // share of paths never depleted before lifeExpectancy
  medianEndingMinor: Minor;
  /** Real (today's money) portfolio percentiles per year from currentAge. */
  percentiles: { age: number; p10: Minor; p50: Minor; p90: Minor }[];
}

const realRate = (nominal: number, inflation: number) => (1 + nominal) / (1 + inflation) - 1;

export function fireNumber(annualExpensesMinor: Minor, swrBps = 400): Minor {
  if (swrBps <= 0) throw new RangeError("swrBps must be positive");
  return (annualExpensesMinor * 10_000n) / BigInt(swrBps);
}

export function simulateFire(i: FireInput): FireResult {
  const mu = (i.expectedReturnBps ?? 1000) / 10_000;
  const sigma = (i.volatilityBps ?? 1600) / 10_000;
  const infl = (i.inflationBps ?? 600) / 10_000;
  const swr = i.swrBps ?? 400;
  const life = i.lifeExpectancy ?? 90;
  const runs = Math.min(Math.max(i.runs ?? 2000, 100), 50_000);
  if (i.currentAge >= life) throw new RangeError("currentAge must be below lifeExpectancy");

  const target = fireNumber(i.annualExpensesMinor, swr);
  const targetF = toFloat(target);
  const expenses = toFloat(i.annualExpensesMinor);
  const savings = toFloat(i.annualSavingsMinor);
  const p0 = toFloat(i.currentPortfolioMinor);

  // Deterministic years-to-FI in real terms (savings at year end).
  const rReal = realRate(mu, infl);
  let yearsToFI: number | null = null;
  { let b = p0;
    for (let y = 0; y <= 100 - i.currentAge; y++) {
      if (b >= targetF) { yearsToFI = y; break; }
      b = b * (1 + rReal) + savings;
    } }
  const fiAge = yearsToFI === null ? null : i.currentAge + yearsToFI;
  const retireAge = i.retirementAge ?? fiAge ?? Math.min(life - 1, 60);

  // Lognormal real returns: match arithmetic mean & stdev of nominal, then deflate.
  const m = 1 + mu;
  const s2 = Math.log(1 + (sigma * sigma) / (m * m));
  const lnMu = Math.log(m) - s2 / 2;
  const lnSig = Math.sqrt(s2);
  const z = gaussian(mulberry32(i.seed ?? 42));

  const years = life - i.currentAge;
  const paths: Float64Array[] = [];
  let success = 0;
  const ending: number[] = [];

  for (let r = 0; r < runs; r++) {
    const path = new Float64Array(years + 1);
    let b = p0;
    path[0] = b;
    let depleted = false;
    for (let y = 1; y <= years; y++) {
      const age = i.currentAge + y;
      const nominal = Math.exp(lnMu + lnSig * z()) - 1;
      const real = realRate(nominal, infl);
      b *= 1 + real;
      if (age <= retireAge) b += savings;
      else b -= expenses;
      if (b <= 0) { b = 0; depleted = true; }
      path[y] = b;
    }
    if (!depleted) success++;
    ending.push(b);
    paths.push(path);
  }

  const pct = (xs: number[], q: number) => {
    const s = [...xs].sort((a, b) => a - b);
    const idx = Math.min(s.length - 1, Math.max(0, Math.round(q * (s.length - 1))));
    return s[idx]!;
  };
  const percentiles = [] as FireResult["percentiles"];
  for (let y = 0; y <= years; y++) {
    const col = paths.map((p) => p[y]!);
    percentiles.push({
      age: i.currentAge + y,
      p10: fromFloat(pct(col, 0.1)),
      p50: fromFloat(pct(col, 0.5)),
      p90: fromFloat(pct(col, 0.9)),
    });
  }

  return {
    fireNumberMinor: target,
    yearsToFI,
    fiAge,
    retirementAgeUsed: retireAge,
    successProbability: success / runs,
    medianEndingMinor: fromFloat(pct(ending, 0.5)),
    percentiles,
  };
}
