/**
 * Aggregation sync resilience: error classification, exponential backoff with full jitter,
 * circuit breaking per connection, and the connection state machine.
 */
export type ConnectionStatus =
  | "ACTIVE" | "SYNCING" | "NEEDS_REAUTH" | "MFA_REQUIRED" | "RATE_LIMITED" | "ERROR" | "REVOKED";

export type ErrorClass = "REAUTH" | "MFA" | "RATE_LIMIT" | "TRANSIENT" | "FATAL";

const REAUTH = new Set([
  "ITEM_LOGIN_REQUIRED", "PENDING_EXPIRATION", "CONSENT_EXPIRED", "CONSENT_REVOKED",
  "ACCESS_NOT_GRANTED", "INVALID_ACCESS_TOKEN", "TOKEN_EXPIRED", "AUTHORIZATION_EXPIRED",
]);
const MFA = new Set(["MFA_REQUIRED", "INVALID_MFA", "ITEM_LOCKED", "USER_SETUP_REQUIRED", "OTP_REQUIRED"]);
const RATE = new Set(["RATE_LIMIT_EXCEEDED", "TOO_MANY_REQUESTS", "INSTITUTION_RATE_LIMIT"]);
const TRANSIENT = new Set([
  "INSTITUTION_DOWN", "INSTITUTION_NOT_RESPONDING", "INSTITUTION_NOT_AVAILABLE",
  "INTERNAL_SERVER_ERROR", "PLANNED_MAINTENANCE", "PRODUCT_NOT_READY", "TIMEOUT", "ECONNRESET", "FIP_UNAVAILABLE",
]);

export function classifyError(code: string, httpStatus?: number): ErrorClass {
  if (REAUTH.has(code)) return "REAUTH";
  if (MFA.has(code)) return "MFA";
  if (RATE.has(code) || httpStatus === 429) return "RATE_LIMIT";
  if (TRANSIENT.has(code) || (httpStatus !== undefined && httpStatus >= 500)) return "TRANSIENT";
  return "FATAL";
}

export interface BackoffPolicy {
  baseMs: number;     // default 30s
  capMs: number;      // default 6h
  maxAttempts: number;// default 8 (~ covers a ~day of outage)
}
export const DEFAULT_BACKOFF: BackoffPolicy = { baseMs: 30_000, capMs: 6 * 3_600_000, maxAttempts: 8 };

/** AWS-style "full jitter": sleep = random(0, min(cap, base·2^attempt)). attempt is 1-based. */
export function backoffDelay(attempt: number, policy = DEFAULT_BACKOFF, rand: () => number = Math.random): number {
  const exp = Math.min(policy.capMs, policy.baseMs * 2 ** (attempt - 1));
  return Math.floor(rand() * exp);
}

export interface ConnectionSyncState {
  status: ConnectionStatus;
  consecutiveFailures: number;
  nextRetryAt: Date | null;
  lastErrorCode: string | null;
}

export interface SyncOutcome { ok: true }
export interface SyncFailure { ok: false; code: string; httpStatus?: number; retryAfterSec?: number }

export interface Transition {
  next: ConnectionSyncState;
  /** Side-effects the orchestrator must perform. */
  actions: ("NOTIFY_USER_REAUTH" | "NOTIFY_USER_MFA" | "SCHEDULE_RETRY" | "ALERT_OPS" | "AUDIT")[];
}

export function onSyncResult(
  prev: ConnectionSyncState, result: SyncOutcome | SyncFailure, now = new Date(),
  policy = DEFAULT_BACKOFF, rand: () => number = Math.random,
): Transition {
  if (result.ok) {
    return { next: { status: "ACTIVE", consecutiveFailures: 0, nextRetryAt: null, lastErrorCode: null }, actions: ["AUDIT"] };
  }
  const cls = classifyError(result.code, result.httpStatus);
  const failures = prev.consecutiveFailures + 1;
  const base = { consecutiveFailures: failures, lastErrorCode: result.code };

  switch (cls) {
    case "REAUTH":
      // Never auto-retry: hammering with a dead token can lock the user's bank login.
      return { next: { ...base, status: "NEEDS_REAUTH", nextRetryAt: null }, actions: ["NOTIFY_USER_REAUTH", "AUDIT"] };
    case "MFA":
      return { next: { ...base, status: "MFA_REQUIRED", nextRetryAt: null }, actions: ["NOTIFY_USER_MFA", "AUDIT"] };
    case "RATE_LIMIT": {
      const delay = result.retryAfterSec ? result.retryAfterSec * 1000 : backoffDelay(failures, policy, rand);
      return { next: { ...base, status: "RATE_LIMITED", nextRetryAt: new Date(now.getTime() + Math.max(delay, policy.baseMs)) }, actions: ["SCHEDULE_RETRY", "AUDIT"] };
    }
    case "TRANSIENT":
      if (failures >= policy.maxAttempts) {
        return { next: { ...base, status: "ERROR", nextRetryAt: null }, actions: ["ALERT_OPS", "AUDIT"] };
      }
      return { next: { ...base, status: "ERROR", nextRetryAt: new Date(now.getTime() + backoffDelay(failures, policy, rand)) }, actions: ["SCHEDULE_RETRY", "AUDIT"] };
    default:
      return { next: { ...base, status: "ERROR", nextRetryAt: null }, actions: ["ALERT_OPS", "AUDIT"] };
  }
}

/**
 * Redis token-bucket key/limits for provider + per-connection rate limiting.
 * The Lua script lives in the API service; this computes the config deterministically.
 */
export const rateLimitKeys = (provider: string, connectionId: string) => ({
  provider: { key: `rl:provider:${provider}`, capacity: 100, refillPerSec: 50 },
  connection: { key: `rl:conn:${connectionId}`, capacity: 2, refillPerSec: 1 / 900 }, // ≤ 1 manual refresh / 15 min
});
