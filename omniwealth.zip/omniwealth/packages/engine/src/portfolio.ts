import { divRound, Minor, sum, toFloat } from "./money.js";
import type { AssetClass } from "./netWorth.js";

export interface HoldingInput {
  securityId: string;
  symbol: string;
  assetClass: AssetClass;
  quantity: number;              // fractional allowed
  lastPriceMinor: Minor;
  prevCloseMinor: Minor;
  costBasisMinor: Minor;         // total for open position
  realizedPnlYtdMinor?: Minor;
  dividendsTtmMinor?: Minor;
}

export interface HoldingMetrics {
  securityId: string;
  symbol: string;
  assetClass: AssetClass;
  marketValueMinor: Minor;
  unrealizedPnlMinor: Minor;
  unrealizedPnlPct: number;
  dayChangeMinor: Minor;
  dividendYieldPct: number;
  weightPct: number;
}

export interface PortfolioSummary {
  totalValueMinor: Minor;
  totalCostMinor: Minor;
  unrealizedPnlMinor: Minor;
  realizedPnlYtdMinor: Minor;
  dayChangeMinor: Minor;
  dayChangePct: number;
  dividendYieldPct: number;
  allocation: { assetClass: AssetClass; valueMinor: Minor; weightPct: number }[];
  holdings: HoldingMetrics[];
}

const pct = (num: Minor, den: Minor) => (den === 0n ? 0 : Number((num * 1_000_000n) / den) / 10_000);
const qtyValue = (qty: number, priceMinor: Minor): Minor =>
  divRound(BigInt(Math.round(qty * 1e10)) * priceMinor, 10_000_000_000n);

export function summarizePortfolio(holdings: HoldingInput[]): PortfolioSummary {
  const rows = holdings.map((h) => {
    const mv = qtyValue(h.quantity, h.lastPriceMinor);
    const prev = qtyValue(h.quantity, h.prevCloseMinor);
    return { h, mv, prev };
  });
  const total = sum(rows.map((r) => r.mv));
  const prevTotal = sum(rows.map((r) => r.prev));
  const metrics: HoldingMetrics[] = rows.map(({ h, mv, prev }) => ({
    securityId: h.securityId,
    symbol: h.symbol,
    assetClass: h.assetClass,
    marketValueMinor: mv,
    unrealizedPnlMinor: mv - h.costBasisMinor,
    unrealizedPnlPct: pct(mv - h.costBasisMinor, h.costBasisMinor),
    dayChangeMinor: mv - prev,
    dividendYieldPct: pct(h.dividendsTtmMinor ?? 0n, mv),
    weightPct: pct(mv, total),
  }));
  const byClass = new Map<AssetClass, Minor>();
  for (const m of metrics) byClass.set(m.assetClass, (byClass.get(m.assetClass) ?? 0n) + m.marketValueMinor);
  const cost = sum(holdings.map((h) => h.costBasisMinor));
  return {
    totalValueMinor: total,
    totalCostMinor: cost,
    unrealizedPnlMinor: total - cost,
    realizedPnlYtdMinor: sum(holdings.map((h) => h.realizedPnlYtdMinor ?? 0n)),
    dayChangeMinor: total - prevTotal,
    dayChangePct: pct(total - prevTotal, prevTotal),
    dividendYieldPct: pct(sum(holdings.map((h) => h.dividendsTtmMinor ?? 0n)), total),
    allocation: [...byClass].map(([assetClass, valueMinor]) => ({ assetClass, valueMinor, weightPct: pct(valueMinor, total) }))
      .sort((a, b) => Number(b.valueMinor - a.valueMinor)),
    holdings: metrics.sort((a, b) => Number(b.marketValueMinor - a.marketValueMinor)),
  };
}

export interface CashFlow { date: Date; amountMinor: Minor } // + = money in (contribution), − = withdrawal

/** Modified Dietz period return — neutralises contributions so it's comparable to an index. */
export function modifiedDietz(startValue: Minor, endValue: Minor, flows: CashFlow[], start: Date, end: Date): number {
  const T = end.getTime() - start.getTime();
  if (T <= 0) throw new RangeError("end must be after start");
  const netFlow = toFloat(sum(flows.map((f) => f.amountMinor)));
  const weighted = flows.reduce((acc, f) => acc + toFloat(f.amountMinor) * ((end.getTime() - f.date.getTime()) / T), 0);
  const denom = toFloat(startValue) + weighted;
  if (denom === 0) return 0;
  return (toFloat(endValue) - toFloat(startValue) - netFlow) / denom;
}

export function benchmarkComparison(portfolioReturn: number, benchStart: number, benchEnd: number) {
  const benchReturn = benchEnd / benchStart - 1;
  return {
    portfolioReturnPct: Math.round(portfolioReturn * 10_000) / 100,
    benchmarkReturnPct: Math.round(benchReturn * 10_000) / 100,
    alphaPct: Math.round((portfolioReturn - benchReturn) * 10_000) / 100,
  };
}

/** XIRR via bisection (robust; Newton can diverge on irregular SIP flows). Flows: − invest, + value. */
export function xirr(flows: CashFlow[]): number | null {
  if (flows.length < 2) return null;
  const t0 = flows[0]!.date.getTime();
  const npv = (r: number) => flows.reduce((acc, f) =>
    acc + toFloat(f.amountMinor) / Math.pow(1 + r, (f.date.getTime() - t0) / (365 * 86_400_000)), 0);
  let lo = -0.9999, hi = 10;
  let fLo = npv(lo), fHi = npv(hi);
  if (fLo * fHi > 0) return null;
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fMid = npv(mid);
    if (Math.abs(fMid) < 1e-6) return mid;
    if (fLo * fMid < 0) { hi = mid; fHi = fMid; } else { lo = mid; fLo = fMid; }
  }
  return (lo + hi) / 2;
}

/** FIFO realised gain for a sell against open lots. Returns realised PnL and remaining lots. */
export function realizeFifo(
  lots: { acquiredAt: Date; qty: number; unitCostMinor: Minor }[], sellQty: number, sellPriceMinor: Minor,
) {
  const sorted = [...lots].sort((a, b) => a.acquiredAt.getTime() - b.acquiredAt.getTime()).map((l) => ({ ...l }));
  let remaining = sellQty;
  let realized = 0n;
  const consumed: { acquiredAt: Date; qty: number; gainMinor: Minor }[] = [];
  for (const lot of sorted) {
    if (remaining <= 0) break;
    const take = Math.min(lot.qty, remaining);
    const gain = qtyValue(take, sellPriceMinor - lot.unitCostMinor);
    realized += gain;
    consumed.push({ acquiredAt: lot.acquiredAt, qty: take, gainMinor: gain });
    lot.qty -= take;
    remaining -= take;
  }
  if (remaining > 1e-9) throw new RangeError("sell quantity exceeds open lots");
  return { realizedMinor: realized, consumed, openLots: sorted.filter((l) => l.qty > 1e-12) };
}
