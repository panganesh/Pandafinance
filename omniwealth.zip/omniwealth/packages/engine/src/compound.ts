import { fromFloat, Minor, toFloat } from "./money.js";

export interface CompoundInput {
  principalMinor: Minor;
  monthlyContributionMinor: Minor;
  annualReturnBps: number;   // nominal, e.g. 1200 = 12%
  years: number;
  /** Annual increase applied to the monthly contribution (SIP step-up), bps. */
  contributionStepUpBps?: number;
  /** For real (inflation-adjusted) series. */
  inflationBps?: number;
  /** Contributions at start of month (annuity due) vs end. Default end. */
  contributeAtStart?: boolean;
}

export interface CompoundPoint {
  year: number;
  balanceMinor: Minor;
  contributedMinor: Minor;
  interestEarnedMinor: Minor;
  realBalanceMinor: Minor;
}

export interface CompoundResult {
  finalNominalMinor: Minor;
  finalRealMinor: Minor;
  totalContributedMinor: Minor;
  series: CompoundPoint[];
}

/** Monthly-compounded projection with optional annual step-up. Uses effective monthly rate. */
export function projectCompound(i: CompoundInput): CompoundResult {
  if (i.years < 0 || i.years > 100) throw new RangeError("years out of range");
  const rm = Math.pow(1 + i.annualReturnBps / 10_000, 1 / 12) - 1;
  const infl = (i.inflationBps ?? 0) / 10_000;
  const step = (i.contributionStepUpBps ?? 0) / 10_000;

  let bal = toFloat(i.principalMinor);
  let contributed = bal;
  let monthly = toFloat(i.monthlyContributionMinor);
  const series: CompoundPoint[] = [{
    year: 0, balanceMinor: i.principalMinor, contributedMinor: i.principalMinor,
    interestEarnedMinor: 0n, realBalanceMinor: i.principalMinor,
  }];

  for (let y = 1; y <= i.years; y++) {
    for (let m = 0; m < 12; m++) {
      if (i.contributeAtStart) { bal += monthly; bal *= 1 + rm; }
      else { bal *= 1 + rm; bal += monthly; }
      contributed += monthly;
    }
    monthly *= 1 + step;
    const real = bal / Math.pow(1 + infl, y);
    series.push({
      year: y,
      balanceMinor: fromFloat(bal),
      contributedMinor: fromFloat(contributed),
      interestEarnedMinor: fromFloat(bal - contributed),
      realBalanceMinor: fromFloat(real),
    });
  }
  const last = series[series.length - 1]!;
  return {
    finalNominalMinor: last.balanceMinor,
    finalRealMinor: last.realBalanceMinor,
    totalContributedMinor: last.contributedMinor,
    series,
  };
}

/**
 * Required level monthly contribution to reach `targetMinor` from `currentMinor` in `months`
 * at an annual return (end-of-month contributions). Never negative.
 */
export function requiredMonthlyContribution(
  currentMinor: Minor, targetMinor: Minor, months: number, annualReturnBps = 0,
): Minor {
  if (months <= 0) return targetMinor > currentMinor ? targetMinor - currentMinor : 0n;
  const fv = toFloat(targetMinor);
  const pv = toFloat(currentMinor);
  const r = Math.pow(1 + annualReturnBps / 10_000, 1 / 12) - 1;
  const pmt = r === 0
    ? (fv - pv) / months
    : ((fv - pv * Math.pow(1 + r, months)) * r) / (Math.pow(1 + r, months) - 1);
  return pmt <= 0 ? 0n : BigInt(Math.ceil(pmt)); // ceil: never under-ask
}

/** Months needed to reach target with a fixed monthly contribution; null if unreachable within cap. */
export function monthsToTarget(
  currentMinor: Minor, targetMinor: Minor, monthlyMinor: Minor, annualReturnBps = 0, capMonths = 1200,
): number | null {
  if (currentMinor >= targetMinor) return 0;
  const r = Math.pow(1 + annualReturnBps / 10_000, 1 / 12) - 1;
  let bal = toFloat(currentMinor);
  const target = toFloat(targetMinor);
  const m = toFloat(monthlyMinor);
  for (let n = 1; n <= capMonths; n++) {
    bal = bal * (1 + r) + m;
    if (bal >= target) return n;
  }
  return null;
}
