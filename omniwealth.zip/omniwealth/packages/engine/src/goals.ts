import { bps, Minor } from "./money.js";
import { monthsToTarget, requiredMonthlyContribution } from "./compound.js";

export type GoalHorizon = "MONTHLY" | "YEARLY" | "LIFETIME";
export type GoalStatus = "ON_TRACK" | "AT_RISK" | "OFF_TRACK" | "ACHIEVED" | "PAUSED";

export interface GoalState {
  id: string;
  horizon: GoalHorizon;
  priority: number;            // 1 = highest
  targetAmountMinor: Minor;
  currentAmountMinor: Minor;
  targetDate: Date;
  expectedReturnBps?: number;
  autoAllocateBps?: number;    // share of incoming surplus reserved for this goal
  paused?: boolean;
}

export const monthsBetween = (from: Date, to: Date): number =>
  Math.max(0, (to.getUTCFullYear() - from.getUTCFullYear()) * 12 + (to.getUTCMonth() - from.getUTCMonth()));

export interface GoalEvaluation {
  goalId: string;
  progressPct: number;
  remainingMinor: Minor;
  requiredMonthlyMinor: Minor;
  projectedMonths: number | null;
  status: GoalStatus;
}

/** Evaluate a savings-type goal given the user's planned monthly contribution to it. */
export function evaluateGoal(g: GoalState, plannedMonthlyMinor: Minor, now = new Date()): GoalEvaluation {
  const remaining = g.targetAmountMinor > g.currentAmountMinor ? g.targetAmountMinor - g.currentAmountMinor : 0n;
  const months = monthsBetween(now, g.targetDate);
  const required = requiredMonthlyContribution(g.currentAmountMinor, g.targetAmountMinor, months, g.expectedReturnBps ?? 0);
  const projected = monthsToTarget(g.currentAmountMinor, g.targetAmountMinor, plannedMonthlyMinor, g.expectedReturnBps ?? 0);
  const progress = g.targetAmountMinor === 0n ? 100
    : Math.min(100, Number((g.currentAmountMinor * 10_000n) / g.targetAmountMinor) / 100);

  let status: GoalStatus;
  if (g.paused) status = "PAUSED";
  else if (remaining === 0n) status = "ACHIEVED";
  else if (plannedMonthlyMinor >= required) status = "ON_TRACK";
  else if (plannedMonthlyMinor * 100n >= required * 80n) status = "AT_RISK";
  else status = "OFF_TRACK";

  return { goalId: g.id, progressPct: progress, remainingMinor: remaining, requiredMonthlyMinor: required, projectedMonths: projected, status };
}

/** Emergency fund target = months × essential monthly outflow. */
export const emergencyFundTarget = (monthlyEssentialsMinor: Minor, months = 6): Minor =>
  monthlyEssentialsMinor * BigInt(months);

export interface Allocation { goalId: string; amountMinor: Minor }

/**
 * Auto-allocation waterfall for surplus cash or realised investment returns.
 *  Pass 1 — each goal's reserved share (autoAllocateBps), capped at what it still needs.
 *  Pass 2 — leftover fills goals by priority, then earliest target date, up to their need this month
 *           (required monthly contribution), then
 *  Pass 3 — any remaining surplus tops up goals by priority until fully funded.
 */
export function allocateSurplus(amountMinor: Minor, goals: GoalState[], now = new Date()):
  { allocations: Allocation[]; unallocatedMinor: Minor } {
  const active = goals.filter((g) => !g.paused && g.targetAmountMinor > g.currentAmountMinor)
    .sort((a, b) => a.priority - b.priority || a.targetDate.getTime() - b.targetDate.getTime());
  const need = new Map(active.map((g) => [g.id, g.targetAmountMinor - g.currentAmountMinor]));
  const given = new Map<string, Minor>();
  let left = amountMinor;
  const give = (id: string, want: Minor) => {
    const amt = [want, need.get(id)!, left].reduce((a, b) => (a < b ? a : b));
    if (amt <= 0n) return;
    given.set(id, (given.get(id) ?? 0n) + amt);
    need.set(id, need.get(id)! - amt);
    left -= amt;
  };

  for (const g of active) if (g.autoAllocateBps) give(g.id, bps(amountMinor, g.autoAllocateBps));
  for (const g of active) {
    const monthly = requiredMonthlyContribution(g.currentAmountMinor, g.targetAmountMinor,
      Math.max(1, monthsBetween(now, g.targetDate)), g.expectedReturnBps ?? 0);
    give(g.id, monthly - (given.get(g.id) ?? 0n));
  }
  for (const g of active) give(g.id, need.get(g.id)!);

  return {
    allocations: [...given].map(([goalId, amountMinor]) => ({ goalId, amountMinor })),
    unallocatedMinor: left,
  };
}
