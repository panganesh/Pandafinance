/**
 * Money primitives. All ledger values are integer minor units (bigint).
 * Floats are allowed ONLY inside forward-looking projections (compound / Monte Carlo),
 * and are converted back to bigint at the boundary with `fromFloat`.
 */
export type Minor = bigint;
export type Currency = string; // ISO-4217

export interface Money {
  amountMinor: Minor;
  currency: Currency;
}

/** Fixed-point scale used for FX rates and ratios. */
export const RATE_SCALE = 100_000_000n; // 1e8

export const ZERO = 0n;

export const sum = (xs: Iterable<Minor>): Minor => {
  let t = 0n;
  for (const x of xs) t += x;
  return t;
};

export const max = (a: Minor, b: Minor): Minor => (a > b ? a : b);
export const min = (a: Minor, b: Minor): Minor => (a < b ? a : b);
export const abs = (a: Minor): Minor => (a < 0n ? -a : a);

/** Banker's-safe half-up division for bigint (rounds half away from zero). */
export function divRound(n: Minor, d: Minor): Minor {
  if (d === 0n) throw new RangeError("division by zero");
  const neg = n < 0n !== d < 0n;
  const an = abs(n);
  const ad = abs(d);
  const q = (an + ad / 2n) / ad;
  return neg ? -q : q;
}

/** Floor division (used where we must never over-promise, e.g. daily allowance). */
export function divFloor(n: Minor, d: Minor): Minor {
  if (d === 0n) throw new RangeError("division by zero");
  const q = n / d;
  return (n % d !== 0n && (n < 0n) !== (d < 0n)) ? q - 1n : q;
}

/** Convert a float rate (e.g. 83.1234) to scaled bigint. */
export const rateToScaled = (rate: number): bigint => BigInt(Math.round(rate * 1e8));

/** Apply a scaled FX rate: amount * rate / 1e8, rounded. */
export const applyRate = (amount: Minor, scaledRate: bigint): Minor =>
  divRound(amount * scaledRate, RATE_SCALE);

/** Multiply by basis points (1 bp = 0.01%). */
export const bps = (amount: Minor, basisPoints: number): Minor =>
  divRound(amount * BigInt(Math.round(basisPoints)), 10_000n);

export const toFloat = (m: Minor): number => Number(m);
export const fromFloat = (f: number): Minor => {
  if (!Number.isFinite(f)) throw new RangeError(`non-finite money value: ${f}`);
  return BigInt(Math.round(f));
};

/** currency -> value of 1 unit in a common pivot currency (the pivot itself maps to 1). */
export type FxTable = Record<Currency, number>;

/**
 * Convert between currencies via the pivot in a single rounding step.
 * Assumes both currencies use the same minor-unit exponent (true for INR/USD/EUR/GBP;
 * JPY/KWD need exponent handling at ingest).
 */
export function convert(amount: Minor, from: Currency, to: Currency, fx: FxTable): Minor {
  if (from === to) return amount;
  const rFrom = fx[from];
  const rTo = fx[to];
  if (rFrom === undefined) throw new Error(`missing FX rate for ${from}`);
  if (rTo === undefined) throw new Error(`missing FX rate for ${to}`);
  return divRound(amount * rateToScaled(rFrom), rateToScaled(rTo));
}

export function format(m: Money, locale = "en-IN", fractionDigits = 2): string {
  const neg = m.amountMinor < 0n;
  const a = abs(m.amountMinor);
  const unit = 10n ** BigInt(fractionDigits);
  const major = a / unit;
  const frac = (a % unit).toString().padStart(fractionDigits, "0");
  const majorStr = new Intl.NumberFormat(locale).format(major);
  const sym = new Intl.NumberFormat(locale, { style: "currency", currency: m.currency })
    .formatToParts(0).find((p) => p.type === "currency")?.value ?? m.currency;
  return `${neg ? "-" : ""}${sym}${majorStr}${fractionDigits ? "." + frac : ""}`;
}
