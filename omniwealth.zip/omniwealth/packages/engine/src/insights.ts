import { Minor, toFloat } from "./money.js";
import { normalizeMerchant } from "./categorize.js";

export interface TxnLite {
  id: string;
  occurredAt: Date;
  amountMinor: Minor; // positive debit amount
  merchant: string;
  categorySlug?: string;
}

export interface RecurringDetection {
  merchantNormalized: string;
  cadenceDays: number;
  typicalAmountMinor: Minor;
  occurrences: number;
  lastSeenAt: Date;
  nextExpectedAt: Date;
  isSubscription: boolean;
  priceChangeDetected: boolean;
  priceChangePct: number;
  transactionIds: string[];
}

const CADENCES = [7, 14, 30, 91, 182, 365];
const DAY = 86_400_000;

const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
};

/** Detect subscriptions, bills, EMIs and SIPs from history (≥3 occurrences, stable cadence & amount). */
export function detectRecurring(txns: TxnLite[], subscriptionSlugs = ["subscriptions"]): RecurringDetection[] {
  const groups = new Map<string, TxnLite[]>();
  for (const t of txns) {
    const k = normalizeMerchant(t.merchant);
    if (!k) continue;
    (groups.get(k) ?? groups.set(k, []).get(k)!).push(t);
  }
  const out: RecurringDetection[] = [];
  for (const [merchant, list] of groups) {
    if (list.length < 3) continue;
    list.sort((a, b) => a.occurredAt.getTime() - b.occurredAt.getTime());
    const gaps = list.slice(1).map((t, i) => (t.occurredAt.getTime() - list[i]!.occurredAt.getTime()) / DAY);
    const g = median(gaps);
    const cadence = CADENCES.find((c) => Math.abs(g - c) <= Math.max(3, c * 0.1));
    if (!cadence) continue;
    // Require most gaps to agree with cadence (tolerates one skipped/late month).
    const agreeing = gaps.filter((x) => Math.abs(x - cadence) <= Math.max(3, cadence * 0.15)).length;
    if (agreeing / gaps.length < 0.7) continue;

    const amounts = list.map((t) => toFloat(t.amountMinor));
    const med = median(amounts);
    const mad = median(amounts.map((a) => Math.abs(a - med)));
    if (med === 0 || mad / med > 0.15) continue; // amounts too variable → not a fixed bill

    const last = list[list.length - 1]!;
    const prior = median(amounts.slice(0, -1));
    const changePct = prior ? (toFloat(last.amountMinor) - prior) / prior : 0;
    out.push({
      merchantNormalized: merchant,
      cadenceDays: cadence,
      typicalAmountMinor: BigInt(Math.round(med)),
      occurrences: list.length,
      lastSeenAt: last.occurredAt,
      nextExpectedAt: new Date(last.occurredAt.getTime() + cadence * DAY),
      isSubscription: list.some((t) => t.categorySlug && subscriptionSlugs.includes(t.categorySlug)),
      priceChangeDetected: Math.abs(changePct) >= 0.05,
      priceChangePct: Math.round(changePct * 10_000) / 100,
      transactionIds: list.map((t) => t.id),
    });
  }
  return out.sort((a, b) => Number(b.typicalAmountMinor - a.typicalAmountMinor));
}

export interface Anomaly { transactionId: string; score: number; medianMinor: Minor; reason: string }

/**
 * Robust z-score (median/MAD) per merchant, falling back to category.
 * Flags spend > 3.5 robust SDs above typical with ≥5 points of history.
 */
export function detectAnomalies(history: TxnLite[], candidates: TxnLite[], threshold = 3.5): Anomaly[] {
  const byKey = new Map<string, number[]>();
  const push = (k: string, v: number) => (byKey.get(k) ?? byKey.set(k, []).get(k)!).push(v);
  for (const t of history) {
    push(`m:${normalizeMerchant(t.merchant)}`, toFloat(t.amountMinor));
    if (t.categorySlug) push(`c:${t.categorySlug}`, toFloat(t.amountMinor));
  }
  const out: Anomaly[] = [];
  for (const t of candidates) {
    const keys = [`m:${normalizeMerchant(t.merchant)}`, t.categorySlug ? `c:${t.categorySlug}` : ""];
    for (const k of keys) {
      const xs = byKey.get(k);
      if (!xs || xs.length < 5) continue;
      const med = median(xs);
      const mad = median(xs.map((x) => Math.abs(x - med))) || med * 0.05 || 1;
      const score = (0.6745 * (toFloat(t.amountMinor) - med)) / mad;
      if (score > threshold) {
        out.push({
          transactionId: t.id, score: Math.round(score * 100) / 100, medianMinor: BigInt(Math.round(med)),
          reason: k.startsWith("m:") ? "Unusually large for this merchant" : "Unusually large for this category",
        });
      }
      break; // merchant baseline wins when available
    }
  }
  return out;
}

export interface ForecastDay { date: string; inflowMinor: Minor; outflowMinor: Minor; balanceMinor: Minor }

/** Forward cashflow: known recurring series + flat discretionary baseline per day. */
export function forecastCashflow(opts: {
  startBalanceMinor: Minor;
  start: Date;
  days: number;
  recurringOutflows: { nextExpectedAt: Date; cadenceDays: number; amountMinor: Minor }[];
  recurringInflows: { nextExpectedAt: Date; cadenceDays: number; amountMinor: Minor }[];
  dailyDiscretionaryMinor: Minor;
}): ForecastDay[] {
  const out: ForecastDay[] = [];
  let bal = opts.startBalanceMinor;
  const dayKey = (d: Date) => d.toISOString().slice(0, 10);
  const schedule = (series: typeof opts.recurringOutflows) => {
    const m = new Map<string, Minor>();
    const end = opts.start.getTime() + opts.days * DAY;
    for (const s of series) {
      for (let t = s.nextExpectedAt.getTime(); t < end; t += s.cadenceDays * DAY) {
        if (t < opts.start.getTime()) continue;
        const k = dayKey(new Date(t));
        m.set(k, (m.get(k) ?? 0n) + s.amountMinor);
      }
    }
    return m;
  };
  const outs = schedule(opts.recurringOutflows);
  const ins = schedule(opts.recurringInflows);
  for (let d = 0; d < opts.days; d++) {
    const k = dayKey(new Date(opts.start.getTime() + d * DAY));
    const inflow = ins.get(k) ?? 0n;
    const outflow = (outs.get(k) ?? 0n) + opts.dailyDiscretionaryMinor;
    bal += inflow - outflow;
    out.push({ date: k, inflowMinor: inflow, outflowMinor: outflow, balanceMinor: bal });
  }
  return out;
}
