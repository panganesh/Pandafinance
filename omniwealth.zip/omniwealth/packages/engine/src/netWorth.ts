import { convert, FxTable, Minor, sum } from "./money.js";

export type AccountType =
  | "CHECKING" | "SAVINGS" | "CREDIT_CARD" | "LOAN" | "MORTGAGE"
  | "BROKERAGE" | "DEMAT" | "MUTUAL_FUND" | "RETIREMENT_401K" | "RETIREMENT_EPF"
  | "RETIREMENT_PPF_NPS" | "CRYPTO_WALLET" | "REAL_ESTATE" | "CASH"
  | "OTHER_ASSET" | "OTHER_LIABILITY";

export type AssetClass =
  | "EQUITY" | "FIXED_INCOME" | "REAL_ESTATE" | "CASH" | "CRYPTO" | "COMMODITY" | "ALTERNATIVE";

export const LIABILITY_TYPES: ReadonlySet<AccountType> = new Set([
  "CREDIT_CARD", "LOAN", "MORTGAGE", "OTHER_LIABILITY",
]);

/** Default class for an account when no holdings breakdown is available. */
const DEFAULT_CLASS: Partial<Record<AccountType, AssetClass>> = {
  CHECKING: "CASH", SAVINGS: "CASH", CASH: "CASH",
  BROKERAGE: "EQUITY", DEMAT: "EQUITY", MUTUAL_FUND: "EQUITY",
  RETIREMENT_401K: "EQUITY", RETIREMENT_EPF: "FIXED_INCOME", RETIREMENT_PPF_NPS: "FIXED_INCOME",
  CRYPTO_WALLET: "CRYPTO", REAL_ESTATE: "REAL_ESTATE", OTHER_ASSET: "ALTERNATIVE",
};

export interface AccountBalance {
  id: string;
  type: AccountType;
  currency: string;
  /** For liabilities, a positive number means money owed (provider convention normalised at ingest). */
  currentBalanceMinor: Minor;
  includeInNetWorth: boolean;
  balanceAsOf: Date;
  /** Optional per-class breakdown (from holdings) in account currency; must sum to balance. */
  classBreakdown?: Partial<Record<AssetClass, Minor>>;
}

export interface NetWorthResult {
  currency: string;
  assetsMinor: Minor;
  liabilitiesMinor: Minor;
  netWorthMinor: Minor;
  byAssetClass: Record<AssetClass, Minor>;
  liabilitiesByType: Partial<Record<AccountType, Minor>>;
  staleAccountIds: string[];
}

export interface NetWorthOptions {
  baseCurrency: string;
  fx: FxTable;
  now?: Date;
  staleAfterHours?: number;
}

const emptyClasses = (): Record<AssetClass, Minor> => ({
  EQUITY: 0n, FIXED_INCOME: 0n, REAL_ESTATE: 0n, CASH: 0n, CRYPTO: 0n, COMMODITY: 0n, ALTERNATIVE: 0n,
});

export function calculateNetWorth(accounts: AccountBalance[], opts: NetWorthOptions): NetWorthResult {
  const now = opts.now ?? new Date();
  const fx: FxTable = { [opts.baseCurrency]: 1, ...opts.fx };
  const staleMs = (opts.staleAfterHours ?? 48) * 3_600_000;
  const byAssetClass = emptyClasses();
  const liabilitiesByType: Partial<Record<AccountType, Minor>> = {};
  const stale: string[] = [];
  let assets = 0n;
  let liabilities = 0n;

  for (const a of accounts) {
    if (!a.includeInNetWorth) continue;
    if (now.getTime() - a.balanceAsOf.getTime() > staleMs) stale.push(a.id);
    const base = convert(a.currentBalanceMinor, a.currency, opts.baseCurrency, fx);

    if (LIABILITY_TYPES.has(a.type)) {
      // A credit card with a negative balance (overpaid) is effectively a cash asset.
      if (base >= 0n) {
        liabilities += base;
        liabilitiesByType[a.type] = (liabilitiesByType[a.type] ?? 0n) + base;
      } else {
        assets += -base;
        byAssetClass.CASH += -base;
      }
      continue;
    }

    assets += base;
    if (a.classBreakdown) {
      const parts = Object.entries(a.classBreakdown) as [AssetClass, Minor][];
      const converted = parts.map(([k, v]) => [k, convert(v, a.currency, opts.baseCurrency, fx)] as const);
      const residual = base - sum(converted.map(([, v]) => v)); // FX rounding / uninvested cash
      for (const [k, v] of converted) byAssetClass[k] += v;
      byAssetClass.CASH += residual;
    } else {
      byAssetClass[DEFAULT_CLASS[a.type] ?? "ALTERNATIVE"] += base;
    }
  }

  return {
    currency: opts.baseCurrency,
    assetsMinor: assets,
    liabilitiesMinor: liabilities,
    netWorthMinor: assets - liabilities,
    byAssetClass,
    liabilitiesByType,
    staleAccountIds: stale,
  };
}
