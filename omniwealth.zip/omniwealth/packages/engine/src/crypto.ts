/**
 * Envelope encryption for provider access tokens (AES-256-GCM).
 *
 *   token ──AES-256-GCM(DEK, iv, AAD=userId|connectionId)──▶ ciphertext
 *   DEK   ──KMS Encrypt(KEK)──▶ wrappedDEK
 *
 * Stored format: v1:<kekId>:<b64 wrappedDEK>:<b64 iv>:<b64 tag>:<b64 ct>
 * AAD binds the ciphertext to its row, so a token copied to another user's row fails to decrypt.
 * Plaintext DEKs and tokens only ever exist in process memory and are zeroed after use.
 */
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

export interface KeyProvider {
  kekId: string;
  wrap(dek: Buffer): Promise<Buffer>;
  unwrap(wrapped: Buffer, kekId: string): Promise<Buffer>;
}

/** Local KEK provider for dev/test only. Production: AWS KMS / GCP KMS / HashiCorp Vault Transit. */
export class LocalKeyProvider implements KeyProvider {
  constructor(private readonly kek: Buffer, public readonly kekId = "local-dev") {
    if (kek.length !== 32) throw new Error("KEK must be 32 bytes");
  }
  async wrap(dek: Buffer) {
    const iv = randomBytes(12);
    const c = createCipheriv("aes-256-gcm", this.kek, iv);
    const ct = Buffer.concat([c.update(dek), c.final()]);
    return Buffer.concat([iv, c.getAuthTag(), ct]);
  }
  async unwrap(wrapped: Buffer, kekId: string) {
    if (kekId !== this.kekId) throw new Error(`unknown KEK ${kekId}`);
    const d = createDecipheriv("aes-256-gcm", this.kek, wrapped.subarray(0, 12));
    d.setAuthTag(wrapped.subarray(12, 28));
    return Buffer.concat([d.update(wrapped.subarray(28)), d.final()]);
  }
}

const aad = (userId: string, connectionId: string) => Buffer.from(`${userId}|${connectionId}`, "utf8");

export async function encryptToken(plain: string, ctx: { userId: string; connectionId: string }, kp: KeyProvider): Promise<string> {
  const dek = randomBytes(32);
  try {
    const iv = randomBytes(12);
    const c = createCipheriv("aes-256-gcm", dek, iv);
    c.setAAD(aad(ctx.userId, ctx.connectionId));
    const ct = Buffer.concat([c.update(plain, "utf8"), c.final()]);
    const wrapped = await kp.wrap(dek);
    return ["v1", kp.kekId, wrapped, iv, c.getAuthTag(), ct]
      .map((p) => (typeof p === "string" ? p : p.toString("base64"))).join(":");
  } finally {
    dek.fill(0);
  }
}

export async function decryptToken(blob: string, ctx: { userId: string; connectionId: string }, kp: KeyProvider): Promise<string> {
  const parts = blob.split(":");
  if (parts.length !== 6 || parts[0] !== "v1") throw new Error("unsupported token envelope");
  const [, kekId, w, iv, tag, ct] = parts as [string, string, string, string, string, string];
  const dek = await kp.unwrap(Buffer.from(w, "base64"), kekId);
  try {
    const d = createDecipheriv("aes-256-gcm", dek, Buffer.from(iv, "base64"));
    d.setAAD(aad(ctx.userId, ctx.connectionId));
    d.setAuthTag(Buffer.from(tag, "base64"));
    return Buffer.concat([d.update(Buffer.from(ct, "base64")), d.final()]).toString("utf8");
  } finally {
    dek.fill(0);
  }
}

/** Read-only scope guard — reject a link if the provider granted anything that can move money. */
const FORBIDDEN_SCOPE = /(transfer|payment|payment_initiation|write|trade|order|withdraw|deposit_switch|signal)/i;
export function assertReadOnlyScopes(scopes: string[]): void {
  const bad = scopes.filter((s) => FORBIDDEN_SCOPE.test(s));
  if (bad.length) throw new Error(`Non read-only scopes refused: ${bad.join(", ")}`);
}
