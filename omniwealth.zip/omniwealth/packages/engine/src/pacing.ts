import { divFloor, max, Minor } from "./money.js";

export interface PacingInput {
  monthlyIncomeMinor: Minor;
  fixedExpensesMinor: Minor;
  savingsGoalsMinor: Minor;
  daysInMonth: number;
  /** 1-based day of month in the user's timezone. */
  dayOfMonth: number;
  /** Discretionary spend from day 1 up to (not including) today. Excludes fixed bills & transfers. */
  spentBeforeTodayMinor: Minor;
  spentTodayMinor: Minor;
  /** Tolerance band for ON_TRACK, in basis points of expected spend. Default ±10%. */
  toleranceBps?: number;
}

export type PacingStatus = "AHEAD" | "ON_TRACK" | "BEHIND" | "OVERSPENT";

export interface PacingResult {
  disposableMinor: Minor;
  /** Spec formula: (Income − Fixed − Savings) / DaysInMonth */
  baseDailyMinor: Minor;
  /** Re-spread remaining disposable over remaining days (incl. today). */
  adjustedDailyMinor: Minor;
  remainingTodayMinor: Minor;
  spentMonthToDateMinor: Minor;
  disposableRemainingMinor: Minor;
  daysRemaining: number;
  expectedSpentByNowMinor: Minor;
  status: PacingStatus;
}

export function dailyPacing(i: PacingInput): PacingResult {
  if (i.daysInMonth < 28 || i.daysInMonth > 31) throw new RangeError("daysInMonth must be 28–31");
  if (i.dayOfMonth < 1 || i.dayOfMonth > i.daysInMonth) throw new RangeError("dayOfMonth out of range");

  const disposable = max(0n, i.monthlyIncomeMinor - i.fixedExpensesMinor - i.savingsGoalsMinor);
  const days = BigInt(i.daysInMonth);
  const baseDaily = divFloor(disposable, days);

  const daysRemaining = i.daysInMonth - i.dayOfMonth + 1;
  const leftAtStartOfToday = disposable - i.spentBeforeTodayMinor;
  const adjustedDaily = max(0n, divFloor(leftAtStartOfToday, BigInt(daysRemaining)));
  const mtd = i.spentBeforeTodayMinor + i.spentTodayMinor;

  // Expected spend through end of today on a straight line.
  const expected = divFloor(disposable * BigInt(i.dayOfMonth), days);
  const tol = BigInt(i.toleranceBps ?? 1000);
  const lo = expected - (expected * tol) / 10_000n;
  const hi = expected + (expected * tol) / 10_000n;

  let status: PacingStatus;
  if (mtd > disposable) status = "OVERSPENT";
  else if (mtd < lo) status = "AHEAD";
  else if (mtd > hi) status = "BEHIND";
  else status = "ON_TRACK";

  return {
    disposableMinor: disposable,
    baseDailyMinor: baseDaily,
    adjustedDailyMinor: adjustedDaily,
    remainingTodayMinor: adjustedDaily - i.spentTodayMinor, // may go negative → UI shows "over by"
    spentMonthToDateMinor: mtd,
    disposableRemainingMinor: disposable - mtd,
    daysRemaining,
    expectedSpentByNowMinor: expected,
    status,
  };
}

/** Days in month for a given year/month (1-12). */
export const daysInMonth = (year: number, month1: number): number =>
  new Date(Date.UTC(year, month1, 0)).getUTCDate();

/** Calendar parts of `date` in an IANA timezone (pacing must follow the user's local day, not UTC). */
export function localDateParts(date: Date, timeZone: string): { year: number; month: number; day: number } {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" })
    .formatToParts(date);
  const get = (t: string) => Number(parts.find((p) => p.type === t)!.value);
  return { year: get("year"), month: get("month"), day: get("day") };
}
