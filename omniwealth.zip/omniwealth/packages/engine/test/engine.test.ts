import { describe, expect, it } from "vitest";
import { randomBytes, randomUUID } from "node:crypto";
import {
  allocateSurplus, assertReadOnlyScopes, backoffDelay, budgetStatus, calculateNetWorth, categorize,
  convert, createStore, dailyPacing, daysInMonth, decryptToken, detectAnomalies, detectRecurring,
  divFloor, divRound, encryptToken, evaluateGoal, fiftyThirtyTwenty, fireNumber, flushOutbox,
  enqueueQuickAdd, forecastCashflow, localDateParts, LocalKeyProvider, modifiedDietz, monthsToTarget,
  normalizeMerchant, onSyncResult, projectCompound, realizeFifo, requiredMonthlyContribution,
  selectPacing, simulateFire, summarizePortfolio, validateZeroBased, xirr, AppState,
} from "../src/index.js";

const D = (s: string) => new Date(s);

describe("money", () => {
  it("rounds half away from zero and floors correctly for negatives", () => {
    expect(divRound(5n, 2n)).toBe(3n);
    expect(divRound(-5n, 2n)).toBe(-3n);
    expect(divFloor(-5n, 2n)).toBe(-3n);
    expect(divFloor(5n, 2n)).toBe(2n);
  });
  it("converts via pivot in one rounding step", () => {
    // $10.00 → ₹ at 83.25
    expect(convert(1000n, "USD", "INR", { INR: 1, USD: 83.25 })).toBe(83250n);
    expect(convert(83250n, "INR", "USD", { INR: 1, USD: 83.25 })).toBe(1000n);
  });
});

describe("net worth", () => {
  const now = D("2026-10-25T06:00:00Z");
  it("sums assets, subtracts liabilities, converts FX, buckets by asset class", () => {
    const r = calculateNetWorth([
      { id: "sav", type: "SAVINGS", currency: "INR", currentBalanceMinor: 50_000_000n, includeInNetWorth: true, balanceAsOf: now },
      { id: "us", type: "BROKERAGE", currency: "USD", currentBalanceMinor: 1_000_000n, includeInNetWorth: true, balanceAsOf: now,
        classBreakdown: { EQUITY: 900_000n, FIXED_INCOME: 100_000n } },
      { id: "cc", type: "CREDIT_CARD", currency: "INR", currentBalanceMinor: 2_500_000n, includeInNetWorth: true, balanceAsOf: D("2026-10-20T00:00:00Z") },
      { id: "hidden", type: "CASH", currency: "INR", currentBalanceMinor: 999n, includeInNetWorth: false, balanceAsOf: now },
    ], { baseCurrency: "INR", fx: { USD: 83 }, now });
    expect(r.assetsMinor).toBe(50_000_000n + 83_000_000n);
    expect(r.liabilitiesMinor).toBe(2_500_000n);
    expect(r.netWorthMinor).toBe(130_500_000n);
    expect(r.byAssetClass.CASH).toBe(50_000_000n);
    expect(r.byAssetClass.EQUITY).toBe(74_700_000n);
    expect(r.byAssetClass.FIXED_INCOME).toBe(8_300_000n);
    expect(r.staleAccountIds).toEqual(["cc"]);
  });
  it("treats an overpaid credit card as cash", () => {
    const r = calculateNetWorth([{ id: "cc", type: "CREDIT_CARD", currency: "INR", currentBalanceMinor: -10_000n, includeInNetWorth: true, balanceAsOf: new Date() }],
      { baseCurrency: "INR", fx: {} });
    expect(r.netWorthMinor).toBe(10_000n);
  });
});

describe("daily pacing", () => {
  const base = { monthlyIncomeMinor: 10_000_000n, fixedExpensesMinor: 4_000_000n, savingsGoalsMinor: 2_000_000n, daysInMonth: 30 };
  it("implements the spec formula and re-spreads the remainder", () => {
    const r = dailyPacing({ ...base, dayOfMonth: 11, spentBeforeTodayMinor: 1_000_000n, spentTodayMinor: 50_000n });
    expect(r.disposableMinor).toBe(4_000_000n);
    expect(r.baseDailyMinor).toBe(133_333n);
    expect(r.daysRemaining).toBe(20);
    expect(r.adjustedDailyMinor).toBe(150_000n);
    expect(r.remainingTodayMinor).toBe(100_000n);
    expect(r.status).toBe("AHEAD");
  });
  it("flags overspend and never returns a negative allowance", () => {
    const r = dailyPacing({ ...base, dayOfMonth: 20, spentBeforeTodayMinor: 4_100_000n, spentTodayMinor: 0n });
    expect(r.status).toBe("OVERSPENT");
    expect(r.adjustedDailyMinor).toBe(0n);
  });
  it("clamps disposable at zero when commitments exceed income", () => {
    expect(dailyPacing({ ...base, savingsGoalsMinor: 9_000_000n, dayOfMonth: 1, spentBeforeTodayMinor: 0n, spentTodayMinor: 0n }).baseDailyMinor).toBe(0n);
  });
  it("uses the user's local calendar day", () => {
    // 20:00 UTC on Oct 25 is already Oct 26 in India
    expect(localDateParts(D("2026-10-25T20:00:00Z"), "Asia/Kolkata").day).toBe(26);
    expect(daysInMonth(2028, 2)).toBe(29);
  });
});

describe("compound & goals", () => {
  it("matches closed-form annual compounding", () => {
    const r = projectCompound({ principalMinor: 100_000n, monthlyContributionMinor: 0n, annualReturnBps: 1200, years: 10 });
    expect(Number(r.finalNominalMinor)).toBeCloseTo(100_000 * 1.12 ** 10, -1);
    expect(r.series).toHaveLength(11);
  });
  it("applies SIP step-up and inflation", () => {
    const flat = projectCompound({ principalMinor: 0n, monthlyContributionMinor: 1_000_000n, annualReturnBps: 1200, years: 15, inflationBps: 600 });
    const step = projectCompound({ principalMinor: 0n, monthlyContributionMinor: 1_000_000n, annualReturnBps: 1200, years: 15, inflationBps: 600, contributionStepUpBps: 1000 });
    expect(step.finalNominalMinor > flat.finalNominalMinor).toBe(true);
    expect(flat.finalRealMinor < flat.finalNominalMinor).toBe(true);
  });
  it("computes required monthly contribution (PMT)", () => {
    expect(requiredMonthlyContribution(0n, 1200n, 12, 0)).toBe(100n);
    const pmt = requiredMonthlyContribution(0n, 100_000_000n, 120, 1200);
    expect(monthsToTarget(0n, 100_000_000n, pmt, 1200)).toBe(120);
  });
  it("classifies goal status", () => {
    const g = { id: "ef", horizon: "YEARLY" as const, priority: 1, targetAmountMinor: 120_000n, currentAmountMinor: 0n, targetDate: D("2027-10-01") };
    const now = D("2026-10-01");
    expect(evaluateGoal(g, 10_000n, now).status).toBe("ON_TRACK");
    expect(evaluateGoal(g, 8_500n, now).status).toBe("AT_RISK");
    expect(evaluateGoal(g, 1_000n, now).status).toBe("OFF_TRACK");
    expect(evaluateGoal({ ...g, currentAmountMinor: 120_000n }, 0n, now).status).toBe("ACHIEVED");
  });
  it("auto-allocates surplus by reserved share, then monthly need, then priority", () => {
    const now = D("2026-01-01");
    const goals = [
      { id: "A", horizon: "YEARLY" as const, priority: 1, targetAmountMinor: 1000n, currentAmountMinor: 0n, targetDate: D("2026-11-01") },
      { id: "B", horizon: "LIFETIME" as const, priority: 2, targetAmountMinor: 5000n, currentAmountMinor: 0n, targetDate: D("2026-11-01") },
    ];
    const r = allocateSurplus(3000n, goals, now);
    expect(Object.fromEntries(r.allocations.map((a) => [a.goalId, a.amountMinor]))).toEqual({ A: 1000n, B: 2000n });
    expect(r.unallocatedMinor).toBe(0n);
    const reserved = allocateSurplus(1000n, [{ ...goals[0]!, priority: 2 }, { ...goals[1]!, priority: 1, autoAllocateBps: 5000 }], now);
    // B is reserved 50% and is top priority; A still receives its monthly need before B tops up.
    expect(Object.fromEntries(reserved.allocations.map((a) => [a.goalId, a.amountMinor]))).toEqual({ B: 900n, A: 100n });
  });
});

describe("FIRE & Monte Carlo", () => {
  it("computes FIRE number from SWR", () => {
    expect(fireNumber(60_000_000n, 400)).toBe(1_500_000_000n);
  });
  it("computes deterministic years-to-FI with zero real return", () => {
    const r = simulateFire({ currentAge: 30, currentPortfolioMinor: 0n, annualExpensesMinor: 40_000n, annualSavingsMinor: 100_000n,
      expectedReturnBps: 600, inflationBps: 600, volatilityBps: 0, runs: 100 });
    expect(r.yearsToFI).toBe(10);
    expect(r.fiAge).toBe(40);
  });
  it("is reproducible for a seed and bounded", () => {
    const input = { currentAge: 32, currentPortfolioMinor: 2_000_000_000n, annualExpensesMinor: 120_000_000n,
      annualSavingsMinor: 300_000_000n, retirementAge: 45, runs: 1000, seed: 7 };
    const a = simulateFire(input);
    const b = simulateFire(input);
    expect(a.successProbability).toBe(b.successProbability);
    expect(a.successProbability).toBeGreaterThan(0);
    expect(a.successProbability).toBeLessThanOrEqual(1);
    expect(a.percentiles[10]!.p10 <= a.percentiles[10]!.p90).toBe(true);
  });
  it("more savings never lowers success probability (same seed)", () => {
    const base = { currentAge: 35, currentPortfolioMinor: 1_000_000_000n, annualExpensesMinor: 100_000_000n, retirementAge: 50, runs: 1500, seed: 11 };
    const lo = simulateFire({ ...base, annualSavingsMinor: 100_000_000n });
    const hi = simulateFire({ ...base, annualSavingsMinor: 300_000_000n });
    expect(hi.successProbability).toBeGreaterThanOrEqual(lo.successProbability);
  });
});

describe("categorization", () => {
  it("normalizes noisy merchant strings", () => {
    expect(normalizeMerchant("UPI/SWIGGY*ORDER 8812 BLR")).toBe("swiggy");
    expect(normalizeMerchant("NETFLIX.COM 866-579")).toBe("netflix");
  });
  it("user rules beat system rules, MCC and keywords", () => {
    const rules = [
      { id: "sys", userId: null, priority: 1, merchantPattern: "swiggy", categorySlug: "food.dining" },
      { id: "mine", userId: "u1", priority: 100, merchantPattern: "swiggy", categorySlug: "work.meals" },
    ];
    const r = categorize({ rawDescription: "UPI/SWIGGY*ORDER", amountMinor: 45_000n, direction: "DEBIT", mcc: "5812" }, rules);
    expect(r).toMatchObject({ categorySlug: "work.meals", source: "USER", ruleId: "mine" });
  });
  it("falls back through MCC → keywords → provider", () => {
    expect(categorize({ rawDescription: "SOME STORE", mcc: "5411", amountMinor: 1n, direction: "DEBIT" }, []).categorySlug).toBe("food.groceries");
    expect(categorize({ rawDescription: "ACH HDFC HOME LOAN EMI", amountMinor: 1n, direction: "DEBIT" }, []).categorySlug).toBe("debt.emi");
    expect(categorize({ rawDescription: "CREDIT CARD BILL PAYMENT", amountMinor: 1n, direction: "DEBIT" }, []).isTransfer).toBe(true);
    expect(categorize({ rawDescription: "XYZ", amountMinor: 1n, direction: "DEBIT", providerCategory: "ENTERTAINMENT" }, []).source).toBe("PROVIDER");
  });
  it("rejects catastrophic user regexes instead of hanging", () => {
    const r = categorize({ rawDescription: "aaaaaaaaaaaaaaaaaaaaaaaaaaaa!", amountMinor: 1n, direction: "DEBIT" },
      [{ id: "evil", userId: "u", priority: 1, descriptionPattern: "(a+)+$", categorySlug: "x" }]);
    expect(r.categorySlug).not.toBe("x");
  });
});

describe("insights", () => {
  const mk = (id: string, date: string, amt: bigint, merchant = "NETFLIX.COM", cat = "subscriptions") =>
    ({ id, occurredAt: D(date), amountMinor: amt, merchant, categorySlug: cat });
  it("detects monthly subscriptions and price hikes", () => {
    const r = detectRecurring([
      mk("1", "2026-06-05", 64_900n), mk("2", "2026-07-05", 64_900n), mk("3", "2026-08-05", 64_900n),
      mk("4", "2026-09-05", 64_900n), mk("5", "2026-10-05", 69_900n),
      mk("x", "2026-07-11", 30_000n, "Random Cafe", "food.dining"),
    ]);
    expect(r).toHaveLength(1);
    expect(r[0]).toMatchObject({ merchantNormalized: "netflix", cadenceDays: 30, isSubscription: true, priceChangeDetected: true });
  });
  it("flags anomalies with robust z-score", () => {
    const hist = [40_000n, 42_000n, 38_000n, 41_000n, 39_500n, 40_500n].map((a, i) => mk(`h${i}`, `2026-0${i + 1}-10`, a, "Zomato", "food.dining"));
    const a = detectAnomalies(hist, [mk("big", "2026-10-10", 400_000n, "Zomato", "food.dining"), mk("ok", "2026-10-11", 41_000n, "Zomato", "food.dining")]);
    expect(a.map((x) => x.transactionId)).toEqual(["big"]);
  });
  it("forecasts cashflow with recurring items", () => {
    const f = forecastCashflow({ startBalanceMinor: 1000n, start: D("2026-11-01T00:00:00Z"), days: 30,
      recurringOutflows: [{ nextExpectedAt: D("2026-11-05T00:00:00Z"), cadenceDays: 30, amountMinor: 500n }],
      recurringInflows: [{ nextExpectedAt: D("2026-11-01T00:00:00Z"), cadenceDays: 30, amountMinor: 2000n }],
      dailyDiscretionaryMinor: 10n });
    expect(f.at(-1)!.balanceMinor).toBe(1000n + 2000n - 500n - 300n);
  });
});

describe("budgets", () => {
  it("enforces zero-based allocation", () => {
    expect(() => validateZeroBased(1000n, [{ key: "a", allocatedMinor: 900n }])).toThrow(/Unassigned/);
    expect(() => validateZeroBased(1000n, [{ key: "a", allocatedMinor: 1000n }])).not.toThrow();
  });
  it("splits 50/30/20 exactly", () => {
    const s = fiftyThirtyTwenty(100_001n);
    expect(s.NEEDS + s.WANTS + s.SAVINGS).toBe(100_001n);
  });
  it("reports pace per envelope including rollover", () => {
    const st = budgetStatus([
      { key: "dining", allocatedMinor: 30_000n, carriedInMinor: 5_000n },
      { key: "groceries", allocatedMinor: 60_000n },
      { key: "fun", allocatedMinor: 10_000n },
    ], { dining: 10_000n, groceries: 45_000n, fun: 12_000n }, 0.5);
    expect(st.map((s) => s.paceStatus)).toEqual(["UNDER", "OVER", "OVER"]);
    expect(st[0]!.availableMinor).toBe(35_000n);
    expect(st[2]!.overBudget).toBe(true);
  });
});

describe("portfolio", () => {
  it("computes PnL, day delta, allocation", () => {
    const p = summarizePortfolio([
      { securityId: "s1", symbol: "INFY", assetClass: "EQUITY", quantity: 10, lastPriceMinor: 15_000n, prevCloseMinor: 14_500n, costBasisMinor: 100_000n, dividendsTtmMinor: 3_000n },
      { securityId: "s2", symbol: "LIQUIDBEES", assetClass: "CASH", quantity: 50, lastPriceMinor: 1_000n, prevCloseMinor: 1_000n, costBasisMinor: 50_000n },
    ]);
    expect(p.totalValueMinor).toBe(200_000n);
    expect(p.unrealizedPnlMinor).toBe(50_000n);
    expect(p.dayChangeMinor).toBe(5_000n);
    expect(p.allocation[0]).toMatchObject({ assetClass: "EQUITY", weightPct: 75 });
    expect(p.holdings[0]!.unrealizedPnlPct).toBe(50);
  });
  it("XIRR and Modified Dietz", () => {
    expect(xirr([{ date: D("2025-01-01"), amountMinor: -1000n }, { date: D("2026-01-01"), amountMinor: 1100n }])!).toBeCloseTo(0.1, 4);
    // 100 → 220 with a +100 contribution at the midpoint ⇒ gain 20 on avg capital 150
    expect(modifiedDietz(100n, 220n, [{ date: D("2026-07-02"), amountMinor: 100n }], D("2026-01-01"), D("2027-01-01"))).toBeCloseTo(20 / 150, 2);
  });
  it("realizes FIFO gains", () => {
    const r = realizeFifo([{ acquiredAt: D("2024-01-01"), qty: 10, unitCostMinor: 100n }, { acquiredAt: D("2025-01-01"), qty: 10, unitCostMinor: 120n }], 15, 150n);
    expect(r.realizedMinor).toBe(650n);
    expect(r.openLots).toHaveLength(1);
    expect(r.openLots[0]!.qty).toBe(5);
  });
});

describe("sync resilience", () => {
  const fresh = { status: "ACTIVE" as const, consecutiveFailures: 0, nextRetryAt: null, lastErrorCode: null };
  const now = D("2026-10-25T00:00:00Z");
  it("never auto-retries expired tokens or MFA", () => {
    expect(onSyncResult(fresh, { ok: false, code: "ITEM_LOGIN_REQUIRED" }, now).next).toMatchObject({ status: "NEEDS_REAUTH", nextRetryAt: null });
    expect(onSyncResult(fresh, { ok: false, code: "INVALID_MFA" }, now).actions).toContain("NOTIFY_USER_MFA");
  });
  it("backs off exponentially with jitter and caps", () => {
    expect(backoffDelay(1, undefined, () => 1 - 1e-12)).toBe(29_999);
    expect(backoffDelay(4, undefined, () => 1 - 1e-12)).toBe(239_999);
    expect(backoffDelay(30, undefined, () => 1 - 1e-12)).toBe(6 * 3_600_000 - 1);
    const t = onSyncResult(fresh, { ok: false, code: "INSTITUTION_DOWN" }, now, undefined, () => 0.5);
    expect(t.next.nextRetryAt!.getTime() - now.getTime()).toBe(15_000);
  });
  it("respects Retry-After and parks after max attempts", () => {
    expect(onSyncResult(fresh, { ok: false, code: "X", httpStatus: 429, retryAfterSec: 120 }, now).next.nextRetryAt!.getTime() - now.getTime()).toBe(120_000);
    const t = onSyncResult({ ...fresh, consecutiveFailures: 7 }, { ok: false, code: "INSTITUTION_DOWN" }, now);
    expect(t.actions).toContain("ALERT_OPS");
    expect(t.next.nextRetryAt).toBeNull();
  });
  it("resets on success", () => {
    expect(onSyncResult({ ...fresh, consecutiveFailures: 5, status: "ERROR" }, { ok: true }, now).next).toMatchObject({ status: "ACTIVE", consecutiveFailures: 0 });
  });
});

describe("token encryption", () => {
  const kp = new LocalKeyProvider(randomBytes(32));
  const ctx = { userId: randomUUID(), connectionId: randomUUID() };
  it("round-trips with AES-256-GCM envelope", async () => {
    const blob = await encryptToken("access-sandbox-abc123", ctx, kp);
    expect(blob.startsWith("v1:local-dev:")).toBe(true);
    expect(blob).not.toContain("abc123");
    expect(await decryptToken(blob, ctx, kp)).toBe("access-sandbox-abc123");
  });
  it("fails if ciphertext is moved to another user's row (AAD binding)", async () => {
    const blob = await encryptToken("tok", ctx, kp);
    await expect(decryptToken(blob, { ...ctx, userId: randomUUID() }, kp)).rejects.toThrow();
  });
  it("refuses money-movement scopes", () => {
    expect(() => assertReadOnlyScopes(["transactions", "balance", "investments"])).not.toThrow();
    expect(() => assertReadOnlyScopes(["transactions", "transfer"])).toThrow(/transfer/);
  });
});

describe("client store & offline outbox", () => {
  const initial: AppState = {
    baseCurrency: "INR", timezone: "Asia/Kolkata", fx: {}, accounts: [],
    profile: { monthlyIncomeMinor: 10_000_000n, fixedExpensesMinor: 4_000_000n, savingsGoalsMinor: 2_000_000n },
    spendByDay: { "2026-10-01": 100_000n }, today: { year: 2026, month: 10, day: 2, daysInMonth: 31 },
    outbox: [], online: true, privacyMode: false,
  };
  it("counts offline quick-adds in today's pacing optimistically", () => {
    const store = createStore(initial);
    const before = selectPacing(store.getState())!;
    enqueueQuickAdd(store, { accountId: "a", direction: "DEBIT", amountMinor: "25000", currency: "INR", occurredAt: "2026-10-02T09:00:00+05:30" }, randomUUID);
    const after = selectPacing(store.getState())!;
    expect(after.spentMonthToDateMinor - before.spentMonthToDateMinor).toBe(25_000n);
    expect(selectPacing(store.getState())).toBe(after); // memoised
  });
  it("flushes idempotently: 2xx removed, 4xx rejected, 5xx kept", async () => {
    const store = createStore(initial);
    const ids = [1, 2, 3].map(() => enqueueQuickAdd(store, { accountId: "a", direction: "DEBIT", amountMinor: "1", currency: "INR", occurredAt: "2026-10-02" }, randomUUID));
    const rejected = await flushOutbox(store, async (ms) => ms.map((m, i) => ({ clientMutationId: m.clientMutationId, status: [201, 422, 503][i]! })));
    expect(rejected).toEqual([ids[1]]);
    expect(store.getState().outbox.map((m) => m.clientMutationId)).toEqual([ids[2]]);
    expect(store.getState().outbox[0]!.attempts).toBe(1);
  });
});
